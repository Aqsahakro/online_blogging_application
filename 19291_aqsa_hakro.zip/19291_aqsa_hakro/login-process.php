<?php
	require_once("require/connection.php");
	session_start();

	if( isset($_POST['login']) )
	{
		extract($_POST);

		$login_query = "SELECT * FROM `user` 
		WHERE `user`.`email` = ?
		AND `user`.`password` = ?";

		$stmt = mysqli_prepare($connection,$login_query);

		mysqli_stmt_bind_param($stmt,"ss",$email,$password);

		mysqli_stmt_execute($stmt);

		$result = mysqli_stmt_get_result($stmt);

		if( $result->num_rows > 0 )
		{
			$user_info = mysqli_fetch_assoc($result);
			 $_SESSION['user'] =  $user_info;

			if( $user_info['role_id'] == 1 )
			{
				header("location: admin/admin-dashboard.php");
			}elseif( $user_info['role_id'] == 2 )
			{
				header("location: user/user-dashboard.php");
			}
		}
		else
		{
			$message = "Login Failed!! ";
			header("location: login.php?message=$message&color=red");
		}

	}

?>