/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.27-MariaDB : Database - 19291_aqsa_hakro
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`19291_aqsa_hakro` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `19291_aqsa_hakro`;

/*Table structure for table `blog` */

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `blog_title` varchar(200) DEFAULT NULL,
  `post_per_page` int(11) DEFAULT NULL,
  `blog_background_image` text DEFAULT NULL,
  `blog_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`blog_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `blog` */

insert  into `blog`(`blog_id`,`user_id`,`blog_title`,`post_per_page`,`blog_background_image`,`blog_status`,`created_at`,`updated_at`) values 
(101,1,'Manage Stress for Mental Health',3,'mental_health_1.png','Active','2023-05-17 02:27:04',NULL),
(102,1,'Ukraine War',4,'wars.jpg','Active','2023-05-18 10:37:34',NULL),
(103,1,'Climate Change',4,'global.jpg','Active','2023-05-18 10:37:40',NULL),
(104,7,'Digital Trends',2,'trends.jpeg','Active','2023-05-18 10:54:58',NULL),
(105,7,'Self-Fixing and Auto-Code with AI: Debating the Pros and Cons',5,'Ai.jpg','Active','2023-05-18 10:54:28',NULL),
(106,1,'Intricate Yarn Drawings Use Shadows to Give 3D Illusion',3,'art.jpeg','Active','2023-05-23 12:47:29',NULL);

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_title` varchar(100) DEFAULT NULL,
  `category_description` text DEFAULT NULL,
  `category_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `category` */

insert  into `category`(`category_id`,`category_title`,`category_description`,`category_status`,`created_at`,`updated_at`) values 
(1,'Health','A health blog can cover diverse health related concerns such as nutrition and diet, fitness, weight control, diseases, disease management, societal trends affecting health, analysis about health, business of health and health research.','Active','2023-05-22 15:20:55',NULL),
(2,'Tech','Tech blog means blogs or websites that provide technical information like gadgets, apps, Internet, Networking, Mobile, Gadgets, Social media Web design, and more.','InActive','2023-05-22 15:20:23',NULL),
(3,'Climate','When we talk about climate change, we talk about changes in long-term averages of daily weather. Today, children always hear stories from their parents and grandparents about how snow was always piled up to their waists as they trudged off to school','Active','2023-05-22 15:18:48',NULL),
(4,'Politics','A political blog is a form of internet blog (a portmanteau of the term web log) covering politics. From the rise of the first political blogs in the late 1990s, the medium has been associated with individuals often operating outside the formal political and media establishment.','Active','2023-05-22 15:17:46',NULL),
(5,'Wars','This blog defines war, conflict, and competition as a spectrum of political coercion. The blog explains how violence is the primary means of coercion in war.','Active','2023-05-22 15:16:10',NULL),
(6,'Culture','all the ways of life including arts, beliefs and institutions of a population that are passed down from generation to generation.','InActive','2023-05-22 14:48:35',NULL),
(7,'Sports','an activity involving physical exertion and skill in which an individual or a team competes against another or others for entertainment','Active','2023-05-22 15:09:24',NULL),
(8,'Arts','the expression or application of human creative skill and imagination, typically in a visual form such as painting or sculpture, producing works to be appreciated primarily for their beauty or emotional power.','Active','2023-05-23 12:46:15',NULL);

/*Table structure for table `following_blog` */

DROP TABLE IF EXISTS `following_blog`;

CREATE TABLE `following_blog` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) DEFAULT NULL,
  `blog_following_id` int(11) DEFAULT NULL,
  `status` enum('Followed','Unfollowed') DEFAULT 'Followed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`follow_id`),
  KEY `blog_following_id` (`blog_following_id`),
  KEY `follower_id` (`follower_id`),
  CONSTRAINT `following_blog_ibfk_1` FOREIGN KEY (`blog_following_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `following_blog_ibfk_2` FOREIGN KEY (`follower_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `following_blog` */

insert  into `following_blog`(`follow_id`,`follower_id`,`blog_following_id`,`status`,`created_at`,`updated_at`) values 
(1,2,101,'Followed','2023-05-23 14:34:34',NULL);

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) DEFAULT NULL,
  `post_title` varchar(200) NOT NULL,
  `post_summary` text NOT NULL,
  `post_description` longtext NOT NULL,
  `featured_image` text DEFAULT NULL,
  `post_status` enum('Active','InActive') DEFAULT NULL,
  `is_comment_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `blog_id` (`blog_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post` */

insert  into `post`(`post_id`,`blog_id`,`post_title`,`post_summary`,`post_description`,`featured_image`,`post_status`,`is_comment_allowed`,`created_at`,`updated_at`) values 
(1100,101,' Your Mental Health Pal','At Your Mental Health Pal, we believe sensitivity is key. We bring you content catered to your personal needs and spread mental health awareness by talking about real experiences','We also focus on providing practical, actionable solutions to help you change your lifestyle. Most of our content is free to avail, but you can also visit the Your Mental Health Pal Shop for premium content made with love and care.','blogs.jpeg','InActive',1,'2023-05-23 15:37:12','2023-05-23 15:37:12'),
(1101,101,'The Art of Healing Trauma','Heidi Hanson, a blogger, was diagnosed with PTSD in 2007. Soon after began writing a blog to assist other trauma survivors in developing and maintaining a successful self-therapy practice in their daily lives.','Hanson is currently putting the insights, clarity, and understanding from her blog into two books that will combine her love of art with her tremendous ability to write about surviving with PTSD.','trauma.jpg','InActive',1,'2023-05-23 15:37:12','2023-05-23 15:37:12'),
(1102,102,'In Romania, Ukrainian children with special needs struggle','Ukrainian children with special needs are in a state of limbo across Europe, struggling to access vital education and therapy services.','We cannot continue having kids studying in front of the screen one more year, after two years of COVID. That is part of the education, but it\'s not full education. They need to interact,\" Pablo Zapata, head of the United Nations refugee agency (UNHCR) in Romania, told Al Jazeera','children.jpg','InActive',1,'2023-05-23 15:37:12','2023-05-23 15:37:12'),
(1103,102,'Ukraine repels ‘exceptional’ Russia missile, drone attack on Kyiv','Ukraine’s capital Kyiv has come under a Russian aerial attack involving drones, cruise and ballistic missiles in what one Ukrainian military official described as an “exceptional”','It was exceptional in its density — the maximum number of attack missiles in the shortest period of time,” Serhiy Popko, head of Kyiv’s city military administration, said in comments posted on the Telegram messaging app. The aerial attack was the eighth on the capital so far this month.','war1.jpg','Active',1,'2023-05-23 15:37:12','2023-05-23 15:37:12'),
(1108,102,'What USAID’s Climate Strategy Means for Procurement ','An interview on procurement and USAID’s Climate Strategy with Jennifer Norling, Evaluation Division Chief, USAID Bureau for Management, Office of Acquisition and Assistance.','An interview on procurement and USAID’s Climate Strategy with Jennifer Norling, Evaluation Division Chief, USAID Bureau for Management, Office of Acquisition and Assistance.','Firewood.jpeg','Active',1,'2023-05-23 15:37:12','2023-05-23 15:37:12'),
(1113,103,'Global warming set to break key 1.5C limit for first time','Our overheating world is likely to break a key temperature limit for the first time over the next few years, scientists predict. ','Researchers say there\'s now a 66% chance we will pass the 1.5C global warming threshold between now and 2027.\r\nThe chances are rising due to emissions from human activities and a likely El Niño weather pattern later this year.','climate.jpg','Active',1,'2023-05-23 15:37:12','2023-05-23 15:37:12'),
(1127,101,'7 benefits of AIOps for organizations','abc','abc','fitness.jpg','Active',1,'2023-05-23 15:37:12','2023-05-23 15:37:12'),
(1128,106,'Photographer Explores the Beauty ','To do so, Robroek explored Italy from north to south and photographed 100 examples of church architecture that have fallen into decay.>','What we see in his photographs are stunning pieces of craftsmanship slowly crumbling. There is water damage eating away at frescoes, delicate stuccowork crushed under the weight of collapsed roofs, and nature beginning to take back these manmade structures. ','arts.png','Active',1,'2023-05-24 11:47:01','2023-05-23 15:37:12'),
(1129,104,'The Performing Arts Ticket Buyer Media Usage Study','Based on a survey of over 17,000 ticket buyers, this report sheds light on the shifting media consumption and buyer behavior of your core audience, with marketing insights to help you turn data into strategy.','Based on a survey of over 17,000 ticket buyers, this report sheds light on the shifting media consumption and buyer behavior of your core audience, with marketing insights to help you turn data into strategy.','social.jpg','Active',1,'2023-05-23 15:37:12','2023-05-23 15:37:12');

/*Table structure for table `post_atachment` */

DROP TABLE IF EXISTS `post_atachment`;

CREATE TABLE `post_atachment` (
  `post_atachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `post_attachment_title` varchar(200) DEFAULT NULL,
  `post_attachment_path` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_atachment_id`),
  KEY `fk1` (`post_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_atachment` */

/*Table structure for table `post_category` */

DROP TABLE IF EXISTS `post_category`;

CREATE TABLE `post_category` (
  `post_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_category_id`),
  KEY `post_id` (`post_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `post_category_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_category` */

insert  into `post_category`(`post_category_id`,`post_id`,`category_id`,`created_at`,`updated_at`) values 
(3,1113,4,'2023-05-23 12:34:43',NULL),
(5,1127,1,'2023-05-23 12:51:04',NULL),
(6,1128,8,'2023-05-23 12:52:57',NULL),
(7,1129,2,'2023-05-23 14:49:32',NULL);

/*Table structure for table `post_comment` */

DROP TABLE IF EXISTS `post_comment`;

CREATE TABLE `post_comment` (
  `post_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `post_comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_comment_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_comment` */

insert  into `post_comment`(`post_comment_id`,`post_id`,`user_id`,`comment`,`is_active`,`created_at`) values 
(5,1100,3,'nice post . Thank you for posting something like this','Active','2023-05-22 11:16:09'),
(6,1102,5,'nice article, waiting for your another','Active','2023-05-22 11:19:17'),
(7,1101,6,'I read this post your post so nice and very informative post thanks for sharing this post','InActive','2023-05-22 09:49:25'),
(8,1101,4,'Nice post','Active','2023-05-22 09:40:51'),
(9,1102,3,'very interesting, good job and thanks for sharing such a good blog.','Active','2023-05-18 12:43:15'),
(10,1108,2,'Great website, thanks for sharing','InActive','2023-05-22 09:49:40'),
(11,1100,5,'blog is the most importent thing for a website','Active','2023-05-22 09:53:43');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_type` varchar(50) NOT NULL,
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `role` */

insert  into `role`(`role_id`,`role_type`,`is_active`) values 
(1,'Admin','Active'),
(2,'User','Active');

/*Table structure for table `setting` */

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `setting_key` varchar(100) DEFAULT NULL,
  `setting_value` varchar(100) DEFAULT NULL,
  `setting_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`setting_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `setting_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `setting` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` text NOT NULL,
  `phone_number` varchar(200) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `user_image` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `is_approved` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`user_id`,`role_id`,`first_name`,`last_name`,`email`,`password`,`phone_number`,`gender`,`date_of_birth`,`user_image`,`address`,`is_approved`,`is_active`,`created_at`,`updated_at`) values 
(1,1,'Aqsa','Hakro','aqsahakro65@gmail.com','Aqsaaaa1','923060259483','Female','2000-05-01','user_Female.jpg','Hyderabad','Pending','Active','2023-05-22 10:33:18',NULL),
(2,2,'Faraz','Nawaz','faraznawaz12@gmail.com','Farazab3','933041256732','Male','1999-11-18','user_male3.jpg','Karachi','Pending','Active','2023-05-22 10:32:27',NULL),
(3,2,'Nisha','Shaikh','nishashaikh12@gmail.com','Nishabc4','923090876541','Female','1998-10-27','female_user1.png','Karachi','Pending','Active','2023-05-22 11:00:32',NULL),
(4,2,'Shahrukh','Abbasi','shahrukh21@gmail.com','Ahmedab2','923331987432','Male','1994-11-10','user_male.png','Sukker','Pending','Active','2023-05-23 12:09:14',NULL),
(5,2,'Saba','Memon','sabamemon23@gmail.com','Aminame4','923341234876','Female','2000-06-10','user_female1.jpg','Hyderabad','Pending','Active','2023-05-23 12:10:45',NULL),
(6,2,'Shaheer','Qureshi','shaheerqureshi43@gmail.com','Shaheer5','923312874531','Male','2001-09-19','user_male.png','Karachi','Pending','Active','2023-05-22 11:04:31',NULL),
(7,1,'Shayan','Memon','shahyanmemon32@gmail.com','Shahyan2','923331265489','Male','1995-04-20','user_male4.png','Karachi','Pending','Active','2023-05-18 10:43:11',NULL);

/*Table structure for table `user_feedback` */

DROP TABLE IF EXISTS `user_feedback`;

CREATE TABLE `user_feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user_feedback` */

insert  into `user_feedback`(`feedback_id`,`user_id`,`user_name`,`user_email`,`feedback`,`created_at`,`updated_at`) values 
(1,2,'Faraz','faraznawaz12@gmail.com','Easy to publish articles to the web\r\n','2023-05-24 11:49:58',NULL),
(2,NULL,'Bisma','bismashaikh76@gmail.com','Simple to use','2023-05-24 11:50:06',NULL),
(3,NULL,'Fiza','fizashaikh12@gmail.com','As I mentioned earlier, external backlinks','2023-05-24 11:51:00',NULL),
(4,NULL,'Yousef','yousefqureshi54@gmail.com','I used Blogger to make my very first blog and used it to manage it & publish my articles. ','2023-05-24 11:52:06',NULL),
(5,3,'Nisha','nishashaikh12@gmail.com','Analytics are built-in with no necessary plugins!','2023-05-24 11:53:13',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
