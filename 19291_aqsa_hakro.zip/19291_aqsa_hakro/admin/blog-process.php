<?php
	require_once '../require/connection.php';
	session_start();

	if( isset($_POST['add_blog']) )
	{
		extract($_POST);

		$user_id = $_SESSION['user']['user_id'];

		$add_blog_query = "INSERT INTO `blog`(user_id,blog_title,post_per_page,blog_status,blog_background_image)
							VALUES(?,?,?,?,?)";

		$stmt = mysqli_prepare($connection,$add_blog_query);

		mysqli_stmt_bind_param($stmt,'isiss',$user_id,$blog_title,$post_per_page,$status,$image);


		if( mysqli_stmt_execute($stmt) )
		{			
			
			$message = "Blog Added Successfully!!";
			header("location: create-blog.php?message=$message&color=green");	

		}
		else
		{
			$message = "Post not add due to some reason!!";
			header("location: create-blog.php?message=$message&color=red");
		}

	}
	if( isset(($_POST['update_blog'])) )
	{
		extract($_POST);
		
		$update_blog_query = "UPDATE `blog` SET blog_title = '".$blog_title."', post_per_page= '".$post_per_page."',blog_status= '".$status."',blog_background_image= '".$image."'
			WHERE blog_id = '".$blog_id."'";

		$result = mysqli_query($connection,$update_blog_query);

		if( $result )
		{		
			$message = "Blog Updated Successfully!!";
			header("location: create-blog.php?message=$message&color=green");	

		}
		else
		{
			$message = "Failed to Update Blog Information!";
			header("location: create-blog.php?message=$message&color=red");
		}


	}


?>