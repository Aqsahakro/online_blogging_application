<?php
	
	session_start();
	if( isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 1 )
	{
		header("location: ../login.php");
	}

	if( !isset($_SESSION['user']) )
	{
		header("location: ../login.php?message=Please First Login&color=red");
	}


?>