<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<script type="text/javascript">
		showAllPosts();
		function showAllPosts()
		{
			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					document.getElementById('show_all_posts').innerHTML = obj.responseText;
				}
			}
		obj.open("GET",'post-process.php?action=show_posts');
		obj.send();
		}
		function updateStatusActive(post_id)
		{

			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					showAllPosts();
					
				}
			}
		obj.open("GET",'post-process.php?action=active_status&post_id='+post_id);
		obj.send();
		}	
		function updateStatusInActive(post_id)
		{
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					showAllPosts();
					
				}
			}
		obj.open("GET",'post-process.php?action=inactive_status&post_id='+post_id);
		obj.send();

		}
	</script>
</head>
<body>

	<?php
	require_once ("../require/connection.php");
	require_once ("manage-posts.php");
	require_once 'session-maintaince.php';

	$usersQuery = "SELECT * FROM `user`
					WHERE user_id = ".$_SESSION['user']['user_id'];

		$posts = getAllPosts();

	//blog table query
	$getBlogQuery = "SELECT * FROM blog";
	$result = mysqli_query($connection,$getBlogQuery);
	

	//category table query
	$getCategoryQuery = "SELECT * FROM category";
	$data = mysqli_query($connection,$getCategoryQuery);

	//including navBar
	include("include/header.php");

	?>

	<!-- Admin dashboard-->
	<div class="container-fluid">
	<div class="row">

		<!-- Side bar -->
		<?php
		include("include/sidebar.php");
		?>
		<!-- Side bar ends -->

		<!-- Add post Form -->
		<div class="col-10 col-sm-12 col-md-10 col-lg-10 text-black">
			<button type="button" class="btn btn-outline-secondary text-white m-2 bg-dark" style="float: right;" onclick="location.href='#view_posts'">View All Posts</button>
			<div style="text-align: center; margin: 10px;">
			<?php 
					if( isset($_GET['message']) )
					{
					?>
						<p style="color: <?php echo $_GET['color']; ?>">
									
							<?php echo $_GET['message']; ?>
						</p>
					<?php
					}

					?>
			</div>
			<?php 

			if( isset($_GET['post_id']) )
			{
				EditFormPost("post-process.php","POST",$_GET['post_id']);
			}else{
				addPostForm("post-process.php","POST");
			}

				
			?>

	<div class="container-fluid col-sm-12 col-md-10 col-lg-12" id="show_all_posts">
	</div>

	<!-- Admin dashboard Ends-->

	<!-- Footer -->
	<?php
	include("include/footer.php");
	?>
	<!-- Footer Ends-->
	


	 <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

	 


</body>
</html>