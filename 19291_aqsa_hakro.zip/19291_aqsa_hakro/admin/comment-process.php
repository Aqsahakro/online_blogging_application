<?php
	require_once '../require/connection.php';
	require_once ("manage-comments.php");

	$comments =  getAllCommenntsInfo();

	if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'show_comments')
	{ ?>
		<div class="row">
		<div class="col-12" style="text-align: center;">
		<div class="card text-center" align="center" style="width:100%; margin-top: 20px;">
			<div class="card-header bg-dark text-white" style="width:100%;">
			    All Comments
			</div>
			<div class="card-body" style="width:100%;">
			  	<table class="table table-striped">
			  	<thead class="thead">
			   	<tr>
			   		<th>User Name</th>
			   		<th>Post Title</th>
			   		<th>Comment</th>
			   		<th>Current Status</th>
			   		<!-- <th>Commentted on</th> -->
			   		<th>Actions</th>
			   	</tr>
			   	</thead>
			   		<?php
			   		require_once ("../require/connection.php");

					if( $comments->num_rows > 0 )
					{
						while( $row = mysqli_fetch_assoc($comments) )
						{

					?>
						 <div id="post_comment_id"><?php $row['post_comment_id']; ?></div>
						<tr>
						<td>
							<img src="images/<?php echo $row['user_image'];?>" style="width: 50px; border-radius: 50%;"><br>
							<?php echo $row['first_name']."  ". $row['last_name']; ?>		
						</td>
						<td>
							<?php echo $row['post_title']; ?>		
						</td>
						<td>
							<?php echo $row['comment']; ?>		
						</td>
						<td>
							<div>
							<?php echo $row['is_active']; ?>
							</div>		
						</td>
						<!-- <td>
							<?php echo $row['created_at']; ?>		
						</td> -->
						<td>

							<a href="javascript:void(0)" class="btn bg-dark " post_comment_id="<?php echo $row['post_comment_id']; ?>" onclick="updateStatusActive(<?php echo $row['post_comment_id']; ?>)" role="button" aria-disabled="true" style = "color: white; background-color:black; text-decoration: none;"  >
								Active

							</a>

							<a href="javascript:void(0)" class="btn bg-dark m-2 " post_comment_id="<?php echo $row['post_comment_id']; ?>" onclick="updateStatusInActive(<?php echo $row['post_comment_id']; ?>)" role="button" aria-disabled="true" style = "color: white; background-color:black; text-decoration: none;"  >
								InActive

							</a>

						</td>
						</tr>
						<?php
						}
					}
			   		?>
			   	</table>
			</div>
		</div>
		</div>
		</div> 
		<?php
	}
	if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'active_status')
	{

		$update_query = "UPDATE `post_comment` SET is_active = 'Active' 
		WHERE post_comment_id = ".$_REQUEST['post_comment_id'];

		$result = mysqli_query($connection,$update_query);

		$select_query = "SELECT user.`first_name`,user.`last_name` AS full_name,post.*,post_comment.* FROM `post_comment` INNER JOIN post 			   ON post.`post_id` = post_comment.`post_id`
						INNER JOIN `user` ON user.`user_id` = post_comment.`user_id`";



		$select_result = mysqli_query($connection,$select_query);

	}

	 if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'inactive_status')
	{

		$update_query = "UPDATE `post_comment` SET is_active = 'InActive' 
		WHERE post_comment_id = ".$_REQUEST['post_comment_id'];

		$result = mysqli_query($connection,$update_query);

		$select_query = "SELECT user.`first_name`,user.`last_name`,post.*,post_comment.* FROM `post_comment` INNER JOIN post 			   ON post.`post_id` = post_comment.`post_id`
						INNER JOIN `user` ON user.`user_id` = post_comment.`user_id`";



		$select_result = mysqli_query($connection,$select_query);
	}
	
	
?>