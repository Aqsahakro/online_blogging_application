<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<?php
	require_once ("../require/connection.php");
	require_once ("manage-feedback-process.php");
	include("include/header.php");
	$feedback = getAllFeedbacks();
	?>
	<div class="container-fluid">
	<div class="row">
	<?php
		include("include/sidebar.php");
	?>
	<div class="col-10 col-sm-12 col-md-10 col-lg-10 text-black">
	 	<div class="container-fluid">
		<div class="row">
		<div class="col-12 ">
		<div class="card text-center" align="center" style="width:100%; margin-top: 20px;">
			<div class="card-header bg-dark text-white" style="width:100%;">
			    All FeedBacks
			</div>
			<div class="card-body" style="width:100%;">
			  	<table class="table table-striped">
			  	<thead class="thead">
			   	<tr>
			   		<th>User Name</th>
			   		<th>User Email</th>
			   		<th>Feedback</th>
			   		<th>Date</th>
			   	</tr>
			   	</thead>
			   	<?php

					if( $feedback->num_rows > 0 )
					{
						while( $row = mysqli_fetch_assoc($feedback) )
						{
					?>
					
						<tr>
						<td>
							<?php echo $row['user_name']; ?>		
						</td>
						<td>
							<?php echo $row['user_email']; ?>		
						</td>
						<td>
							<?php echo $row['feedback']; ?>		
						</td>
						<td>
							<?php echo $row['created_at']; ?>		
						</td>
						</td>
						</tr>
						<?php
						}
					}
			   		?>
			   	</table>
			</div>
		</div>
		</div>
		</div>
		</div>

	<!-- Footer -->
	<?php
	include("include/footer.php");
	?>
	<!-- Footer Ends-->

	 <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>
