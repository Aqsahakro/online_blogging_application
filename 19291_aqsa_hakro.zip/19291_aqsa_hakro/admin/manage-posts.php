<?php
	require_once ("../require/connection.php");

	function getAllPosts()
	{
		global $connection;
		$getAllPostsQuery = "SELECT * FROM `post` INNER JOIN blog 
		WHERE post.`blog_id` = blog.`blog_id`";
		$result = mysqli_query($connection,$getAllPostsQuery);
		return $result;

	}
	function getPostsByPostId($post_id)
	{
		global $connection;
		$get_posts = "SELECT * FROM `post` WHERE `post`.`post_id` = $post_id";
		$result = mysqli_query($connection,$get_posts);
		$data = mysqli_fetch_assoc($result);	
		return $data;
	}

	function addPostForm($action = "",$method="POST")
	{
		global $connection;

		//getting Blogs
		$getBlogs = "SELECT * FROM blog";
		$blogs = mysqli_query($connection,$getBlogs);

		//getting categories
		$getcategory = "SELECT *  FROM category";
		$category = mysqli_query($connection,$getcategory);

	?>
		<!-- Add Post form -->
		<div class="card text-center m-5" style="background-color: #A8A8A8;">
			  <div class="card-header bg-dark text-white">
			    Add Posts
			  </div>
			  <div class="card-body text-center">
			    <p class="card-text">
			    <center>
			    <form action="post-process.php" method="POST">
				<table>
				<tr>
					<th>Post Title</th>
					<td>
						<input type="text" name="post_title" required>
					</td>
				</tr>
				<tr>
					<th>Post Category</th>
					<td>
						<select name="category_id">
						<option value="none" selected disabled hidden>Select an Option</option>
						<?php
						if ( $category-> num_rows > 0 ) 
							while ( $result = mysqli_fetch_assoc($category) )
							{ ?>
								<option value="<?php echo  $result['category_id']; ?>"><?php  echo   $result['category_title'];; ?></option>	
							<?php
							}
							?>						
						</select>
					</td>
				</tr>
				<tr>
					<th>Blog Tittle:</th>
					<td>
						<select name="blog_id">
						<option value="none" selected disabled hidden>Select an Option</option>
						<?php
						if ( $blogs-> num_rows > 0 ) 
							while ( $row = mysqli_fetch_assoc($blogs) ) { ?>
							<option value="<?php echo $row['blog_id']; ?>"><?php  echo $row['blog_title']; ?></option>	
							<?php
							}
							?>				
						</select>
					</td>
				</tr>
				<tr>
					<th>Post Summary</th>
					<td>
						<textarea cols="50" rows="2" name="post_summary" required></textarea>
					</td>
				</tr>
				<tr>
					<th>Post Description</th>
					<td>
						<textarea cols="50" rows="10" name="post_desc" required></textarea>
					</td>
				</tr>
				<tr>
					<th>Post Status: </th>
					<td>
					<select name="status">
					<option value="none" selected disabled hidden>Select an Option</option>
					<option>Active</option>
					<option>Inactive</option>
					</select>
					</td>
				</tr>
				<tr>
					<th>Add Featured Image: </th>
					<td colspan="2">
						<input type="file" name="image" id="image" accept="image/png, image/jpeg"  />
					</td>
				</tr>
				<!-- <tr>
				<th>Post Attachment:</th>
				<td>
				<input type="text" name="post_attachment" onclick="postAttachment()">
				</td>
				</tr> -->
				<tr>							
					<td align="center" colspan="2" >
						<input type="submit" name="add_post" value="Add Post" >
					</td>
				</tr>
				</table>
				</form>
				</center>
			  </div>
			</div> 
			<?php
		}

	function EditFormPost($action = "",$method="POST",$post_id)
	{
		global $connection;

		$data = getPostsByPostId($post_id);
		
		$getBlogs = "SELECT * FROM blog";
		$blogs = mysqli_query($connection,$getBlogs);
		if( $blogs->num_rows > 0)
			$row = mysqli_fetch_assoc($blogs);
		?>
		<div class="card text-center m-5" style="background-color: #A8A8A8;">
			<div class="card-header bg-dark text-white">
			    Update Posts
			 </div>
		 <div class="card-body text-center">
			<p class="card-text">
			<center>
		  	<form action="<?php echo $action; ?>" method="<?php echo $method; ?>">
			<input type="hidden" name="post_id" value="<?php echo $data['post_id'];?>">
			<center>
			    <form action="post-process.php" method="POST">
				<table>
					<tr>
						<th>Post Title</th>
						<td>
							<input type="text" name="post_title" required value="<?php echo $data['post_title'];?>">
						</td>
					</tr>
					<tr>
					<?php 
						$get_category = "SELECT * FROM category";
						$category = mysqli_query($connection,$get_category);
						if( $category->num_rows > 0)
							$result = mysqli_fetch_assoc($category);

						$get_post_category_id = "SELECT * FROM post_category";
						$post_category = mysqli_query($connection,$get_post_category_id);
						if ( $post_category->num_rows > 0 )
							$res = mysqli_fetch_assoc($post_category);


					?>
					<th>Post Category</th>
					<td>
						<select name="category_id">
						<option value="<?php if( $res['category_id'] == $result['category_id'] ){echo "selected"; } else { echo '';}?>"><?php  echo $result['category_title']; ?></option>
											
						</select>
					</td>
					</tr>
					<tr>
						<th>Blog Tittle:</th>
						<td>
						<select name="blog_id">
						<option value="<?php if( $data['blog_id'] == $row['blog_id'] ){echo "selected"; } else { echo '';}?>"><?php  echo $row['blog_title']; ?></option>	
						</select>
						</td>
					</tr> 
					<tr>
						<th>Post Summary</th>
						<td>
						<textarea cols="50" rows="2" name="post_summary" required><?php echo $data['post_summary'];?>></textarea>
						</td>
					</tr>
					<tr>
						<th>Post Description</th>
						<td>
							<textarea cols="50" rows="10" name="post_desc" required ><?php echo $data['post_description'];?></textarea>
						</td>
					</tr>
					<tr>
						<th>Post Status:</th>
						<td>
						<select name="status">
							<option <?php if( $data['post_status'] == 'Active' ){echo "selected"; }else { echo '';}?> >Active</option>
							<option <?php if( $data['post_status'] == 'InActive' ){echo "selected"; }else { echo '';}?>>Inactive</option>
						</select>
					</tr>
					<tr>
						<th>Add Featured Image: </th>
						<td colspan="2">
							<input type="file" name="image" id="image" accept="image/png, image/jpeg" />
						</td>
					</tr>
					<tr>							
						<td align="center" colspan="2">
							<input type="submit" name="update_post" value="Update Post">
						</td>
					</tr>
				</table>
				</form>
				</center>
			    </p>
			  </div>
			</div>
			 <?php

	}

?>
</body>
</html>