<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<script type="text/javascript">
		showAllComments();
		function showAllComments()
		{
			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					document.getElementById('show_all_comments').innerHTML = obj.responseText;
				}
			}
			obj.open("GET",'comment-process.php?action=show_comments');
			obj.send();
		}
		function updateStatusActive(post_comment_id)
		{
			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					showAllComments();
				}
			}
		obj.open("GET",'comment-process.php?action=active_status&post_comment_id='+post_comment_id);
		obj.send();
		}
		function updateStatusInActive(post_comment_id)
		{
			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					showAllComments();
				}
			}
		obj.open("GET",'comment-process.php?action=inactive_status&post_comment_id='+post_comment_id);
		obj.send();
		}
		

	</script>
</head>
<body>
	<?php
		require_once ("../require/connection.php");
		require_once ("manage-comments.php");

		$comments =  getAllCommenntsInfo();

		include("include/header.php");
	?>

	<div class="container-fluid">
	<div class="row">

	<!-- Side bar -->
	<?php
		include("include/sidebar.php");
	?>
	<!-- Side bar ends -->

	<div class="col-10  col-sm-12 col-md-10 col-lg-10 text-black">
			<div style="text-align: center; margin: 10px;">
			<?php 
					if( isset($_GET['message']) )
					{
					?>
						<p style="color: <?php echo $_GET['color']; ?>">
									
							<?php echo $_GET['message']; ?>
						</p>
					<?php
					}

					?>
			</div>
		<div class="container-fluid" id="show_all_comments">
		</div>

		<!-- Footer -->
	<?php
	include("include/footer.php");
	?>
	<!-- Footer Ends-->

	 <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>


