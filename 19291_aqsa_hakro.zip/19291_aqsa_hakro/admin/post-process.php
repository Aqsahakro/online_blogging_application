<?php
	require_once '../require/connection.php';
	require_once ("manage-posts.php");
	session_start();

	$posts = getAllPosts();

	if( isset($_POST['add_post']) )
	{
		extract($_POST);
		$add_post_query = "INSERT INTO `post`(blog_id,post_title,post_summary,post_description,post_status,featured_image)
		VALUES('".$blog_id."','".$post_title."','".$post_summary."','".$post_desc."','".$status."','".$image."')";

		$result = mysqli_query($connection,$add_post_query);

		$post_last_insert_id =  mysqli_insert_id($connection);


		if($result)
		{
			$post_last_insert_id =  mysqli_insert_id($connection);

			$insert_into_post_category = "INSERT INTO post_category(post_id,category_id)
										  VALUES('".$post_last_insert_id."','".$category_id."')";

			$data = mysqli_query($connection,$insert_into_post_category);

			
			$post_attachment_query = "INSERT INTO `post_atachment`(post_id,post_attachment_title,post_attachment_path)
										VALUES('".$post_last_insert_id."','".$post_attachment_title."')";

			$post_atachment = mysqli_query($connection,$post_attachment_query);

				if($post_atachment)
				{			
					
					$message = "Post Added Successfully!!";
					header("location: admin-manage-posts.php?message=$message&color=green");	

				}
				else
				{
					$message = "Post not add due to some reason!!";
					header("location: admin-manage-posts.php?message=$message&color=red");
				}

		}

	}
	if( isset(($_POST['update_post'])) )
	{
		extract($_POST);
		
		$update_post_query = "UPDATE `post` SET post_title = '".$post_title."', post_summary= '".$post_summary."',post_description= '".$post_desc."',featured_image= '".$image."'
			WHERE post_id = '".$post_id."'";

		$result = mysqli_query($connection,$update_post_query);

		if( $result )
		{		
			$message = "Post Updated Successfully!!";
			header("location: admin-manage-posts.php?message=$message&color=green");	

		}
		else
		{
			$message = "Failed to Update Post Information!";
			header("location: admin-manage-posts.php?message=$message&color=red");
		}

	}

	if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'show_posts')
	{ ?>
		<div class="row">
		<div class="col-12 col-sm-12 col-md-4 col-lg-12" id="view_posts">
		<div class="card text-center" align="center" style="width:100%; margin-top: 20px;">
			<div class="card-header bg-dark text-white" style="width:100%;">
			    All Posts
			</div>
			<p>
					<?php 
						if(isset($_GET['message']))
						{
							?>
								<p style="color: <?php echo $_GET['color']; ?>">
									
									<?php echo $_GET['message']; ?>
								</p>
							<?php
						}

					?>
			</p>
			<div class="card-body" style="width:100%;">
			  	<table class="table table-striped">
			  	<thead class="thead">
			   	<tr>
			   		<th>Post Title</th>
			   		<!-- <th>Post Category</th> -->
			   		<th>Blog Title</th>
			   		<th>Post Summary</th>
			   		<th>Post Description </th>
			   		<th>Post Status</th>
			   		<th>Featured Image</th>
			   		<th>Actions</th>
			   	</tr>
			   	</thead>
			   	<?php
			   		require_once ("../require/connection.php");

					if( $posts->num_rows > 0 )
					{
						while( $row = mysqli_fetch_assoc($posts) )
						{
						?>
						<tr>
						<td>
							<?php echo $row['post_title']; ?>		
						</td>	 
						<td>
							<?php echo $row['blog_title']; ?>		
						</td>
						<td>
							<?php echo $row['post_summary']; ?>		
						</td>
						<td>
							<?php echo $row['post_description']; ?>		
						</td>
						<td>
							<?php echo $row['post_status']; ?>		
						</td>
						<td>
							<img src="images/<?php echo $row['featured_image'];?>" style="width: 50%;">
						</td> 	
						</td>
						<td>
						<a href="javascript:void(0)" class="btn bg-dark " post_id="<?php echo $row['post_id']; ?>" onclick="updateStatusActive(<?php echo $row['post_id']; ?>)" role="button" aria-disabled="true" style = "color: white;"  >Active
						</a>
						<a href="javascript:void(0)" class="btn bg-dark m-2 " post_id="<?php echo $row['post_id']; ?>" onclick="updateStatusInActive(<?php echo $row['post_id']; ?>)" role="button" aria-disabled="true" style = "color: white;"  >InActive
						</a>
						</td> 

						<td>
							<a href="admin-manage-posts.php?post_id=<?php echo $row['post_id']; ?>"  class="btn bg-dark" tabindex="-1" role="button" aria-disabled="true" style = "color: white;">Update</a>		
						</td>
						</tr>
						<?php
						}
					}
			   		?>
			   </table>
			</div>
			</div>
		</div>
		</div>
		<?php
	}
	if ( isset($_REQUEST['action']) && $_REQUEST['action'] == 'active_status' )
	{

	 	$update_query = "UPDATE `post` SET post_status = 'Active' 
	 	WHERE post_id = ".$_REQUEST['post_id'];

	 	$result = mysqli_query($connection,$update_query);

	 	$select_query = "SELECT * FROM post";


	 	$select_result = mysqli_query($connection,$select_query);	
	}

	if ( isset($_REQUEST['action']) && $_REQUEST['action'] == 'inactive_status' )
	{

	 	$update_query = "UPDATE `post` SET post_status = 'InActive' 
	 	WHERE post_id = ".$_REQUEST['post_id'];

	 	$result = mysqli_query($connection,$update_query);

	 	$select_query = "SELECT * FROM post";


	 	$select_result = mysqli_query($connection,$select_query);	
	}



?>