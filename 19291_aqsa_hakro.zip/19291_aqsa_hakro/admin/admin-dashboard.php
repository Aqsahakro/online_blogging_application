<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		body{
			font-size: 20px;
		}
	</style>
</head>
<body>
	 <?php
		require_once 'session-maintaince.php';
		require_once ("../require/connection.php");

		// Users Query
		$usersQuery = "SELECT * FROM `user`
						WHERE user_id = ".$_SESSION['user']['user_id'];


			// echo $_SESSION['user']['user_id'];

		$user = mysqli_query($connection,$usersQuery);
		if( $user->num_rows > 0 )
		{
			$users = mysqli_fetch_assoc($user);
			// echo $users['user_image'];
			// die;

		}

		//Total Users Query
		$totalUsersQuery = "SELECT COUNT(*) AS Total_users FROM `user`
							WHERE role_id = 2";

		$result = mysqli_query($connection,$totalUsersQuery);

		if( $result->num_rows > 0 )
		{
			$total_users = mysqli_fetch_assoc($result);

		}

		//Active Users Query
		$activeUsersQuery = "SELECT COUNT(*) AS Active_users FROM `user`
							WHERE role_id = 2 AND is_active = 'active'";

		$active_users = mysqli_query($connection,$activeUsersQuery);

		if( $active_users->num_rows > 0 )
		{
			$totalActive_users = mysqli_fetch_assoc($active_users);
		}

		//Total Categories Query
		$categoriesQuery = "SELECT COUNT(*) AS Total_categories FROM `category`";

		$category = mysqli_query($connection,$categoriesQuery);

		if( $category->num_rows > 0 )
		{
			$total_categories = mysqli_fetch_assoc($category);
		}

		//Active Categories Query
		$activeCategoryQuery = "SELECT COUNT(*) AS active_categories FROM `category`
							WHERE category_status = 'active'";

		$active_category = mysqli_query($connection,$activeCategoryQuery);

		if( $active_category->num_rows > 0 )
		{
			$totalActive = mysqli_fetch_assoc($active_category);
		}

		//Posts Query
		$postsQuery = "SELECT COUNT(*) AS total_posts FROM `post`";

		$posts = mysqli_query($connection,$postsQuery);

		if( $posts->num_rows > 0 )
		{
			$totalPosts = mysqli_fetch_assoc($posts);
		}

		// Active Posts Query
		$activePostsQuery = "SELECT COUNT(*) AS active_posts FROM `post`
					   WHERE post_status = 'active'";

		$activePosts = mysqli_query($connection,$activePostsQuery);

		if( $activePosts->num_rows > 0 )
		{
			$active = mysqli_fetch_assoc($activePosts);
		}

		//Comments Query
		$commentQuery = "SELECT COUNT(*) AS total_comments FROM `post_comment`";

		$comment = mysqli_query($connection,$commentQuery);

		if( $comment->num_rows > 0 )
		{
			$totalComments = mysqli_fetch_assoc($comment);
		}

		// Active comments Query
		$activeCommentsQuery = "SELECT COUNT(*) AS active_comments FROM `post_comment`
					   WHERE is_active = 'active'";

		$activeComments = mysqli_query($connection,$activeCommentsQuery);

		if( $activeComments->num_rows > 0 )
		{
			$allActiveComments = mysqli_fetch_assoc($activeComments);
		}

		//including navBar
		include("include/header.php");
	?>

	<!-- Admin dashboard -->
	<div class="container-fluid">
	<div class="row">
		<?php
		include("include/sidebar.php");
		?>
		</center>

		<!-- middle portion -->
		<div class="col-6 text-black">

		<!-- Heading -->
		<div class="row">
			<div class="col-12 col-sm-12 col-md-3 col-lg-8 mt-5">
				<h2 class="text-center"><b>Statistics</b></h2>
			</div>
		</div>
		<!-- Heading ends -->

		<!-- Cards -->
		<div class="row">

		<div class="card me-auto text-black" style="max-width: 18rem;  background-color: #e5e4e2; color: navy;  margin: 30px;">
			  <div class="card-header m-2" style="background-color: #76424e; color: white; "><h3><span><b>Users</b>
			  	<svg xmlns="http://www.w3.org/2000/svg" width="30" height="100" fill="currentColor" class="bi bi-people-fill" viewBox="0 0 16 16">
			  <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7Zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm-5.784 6A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216ZM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"/>
			  </svg></span></h3>
			  </div>
			  <div class="card-body">
			   <h1 align="right">

			  </h1> 
			  <div class="card-text"><h1><?php echo $total_users['Total_users']; ?></h1><p>total users</p></div>
			  <button type="button" class="btn btn-dark text-white">
				  Active Users: <span class="badge text-bg-secondary"><?php echo $totalActive_users['Active_users']; ?></span>
			   </button>
			  </div>
		</div>


		<div class="card me-auto  text-black" style="max-width: 18rem; color: navy; background-color: #e5e4e2; margin: 30px;" >
			  <div class="card-header m-2" style="background-color: #76424e; color: white; "><h3><span><b>Categories</b>
			  <svg xmlns="http://www.w3.org/2000/svg" width="30" height="100" fill="currentColor" class="bi bi-card-list" viewBox="0 0 16 16">
			  <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z"/>
			  <path d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-1-5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zM4 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm0 2.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z"/>
			</svg>
			  </div></h3></span>
			  <div class="card-body">
			  <div class="card-text"><h1><?php echo $total_categories['Total_categories']; ?></h1><p>Categories</p></div>
			  <button type="button" class="btn btn-dark text-white">
				  Active Categories: <span class="badge text-bg-secondary"><?php echo $totalActive['active_categories']; ?></span>
			   </button>
			  </div>
		</div>

		<div class="card me-auto  text-black" style="max-width: 18rem; background-color: #e5e4e2; color: navy;  margin: 30px;">
			  <div class="card-header m-2" style="background-color: #76424e; color: white; "><h3><span><b>Posts</b>
			  <svg xmlns="http://www.w3.org/2000/svg" width="30" height="100" fill="currentColor" class="bi bi-file-earmark-post" viewBox="0 0 16 16">
			  <path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5h-2z"/>
			  <path d="M4 6.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-7a.5.5 0 0 1-.5-.5v-7zm0-3a.5.5 0 0 1 .5-.5H7a.5.5 0 0 1 0 1H4.5a.5.5 0 0 1-.5-.5z"/>
			  </svg>
			  </div></h3></span>
			  <div class="card-body">
			  <div class="card-text"><h1><?php echo $totalPosts['total_posts']; ?></h1><p>Posts</p></div>
			  <button type="button" class="btn btn-dark text-white">
				  Active Posts: <span class="badge text-bg-secondary"><?php echo $active['active_posts']; ?></span>
			   </button>
			  </div>
		</div>

		<div class="card me-auto text-black" style="max-width: 18rem;  background-color: #e5e4e2; color: navy; margin: 30px;">
			  <div class="card-header m-2" style="background-color: #76424e; color: white; "><h3><span><b>Comments</b>
			  <svg xmlns="http://www.w3.org/2000/svg" width="30" height="100" fill="currentColor" class="bi bi-wechat" viewBox="0 0 16 16">
			  <path d="M11.176 14.429c-2.665 0-4.826-1.8-4.826-4.018 0-2.22 2.159-4.02 4.824-4.02S16 8.191 16 10.411c0 1.21-.65 2.301-1.666 3.036a.324.324 0 0 0-.12.366l.218.81a.616.616 0 0 1 .029.117.166.166 0 0 1-.162.162.177.177 0 0 1-.092-.03l-1.057-.61a.519.519 0 0 0-.256-.074.509.509 0 0 0-.142.021 5.668 5.668 0 0 1-1.576.22ZM9.064 9.542a.647.647 0 1 0 .557-1 .645.645 0 0 0-.646.647.615.615 0 0 0 .09.353Zm3.232.001a.646.646 0 1 0 .546-1 .645.645 0 0 0-.644.644.627.627 0 0 0 .098.356Z"/>
			  <path d="M0 6.826c0 1.455.781 2.765 2.001 3.656a.385.385 0 0 1 .143.439l-.161.6-.1.373a.499.499 0 0 0-.032.14.192.192 0 0 0 .193.193c.039 0 .077-.01.111-.029l1.268-.733a.622.622 0 0 1 .308-.088c.058 0 .116.009.171.025a6.83 6.83 0 0 0 1.625.26 4.45 4.45 0 0 1-.177-1.251c0-2.936 2.785-5.02 5.824-5.02.05 0 .1 0 .15.002C10.587 3.429 8.392 2 5.796 2 2.596 2 0 4.16 0 6.826Zm4.632-1.555a.77.77 0 1 1-1.54 0 .77.77 0 0 1 1.54 0Zm3.875 0a.77.77 0 1 1-1.54 0 .77.77 0 0 1 1.54 0Z"/>
			  </svg></div></h3></span>
			  <div class="card-body">
			  <div class="card-text"><h1><?php echo $totalComments['total_comments']; ?></h1><p>Comments</p></div>
			  <button type="button" class="btn btn-dark text-white">
				  Active Comments: <span class="badge text-bg-secondary"><?php echo $allActiveComments['active_comments']; ?></span>
			   </button>
			  </div>
		</div>


		
		</div>
		</div>
		<!-- middle portion Ends-->


		<!-- side portion -->
		<div class="col-4 col-sm-12 col-md-3 col-lg-3 text-black text-center ">

			<div class="row">
			<h4 style="margin-top: 50px;"><b>Recent Posts</b></h4>
			</div>

			<div class="row">
			<?php
			$get_post_query = "SELECT * FROM post 
								ORDER BY post_id DESC
								LIMIT 5";
			$result = mysqli_query($connection,$get_post_query);

			if ( $result-> num_rows > 0 )
		 	{

			while( $row = mysqli_fetch_assoc($result) )
			{ 
				?> 
				<div class="card m-5" style="max-width: 450px;" style="margin:10%; text-align: center; background-color: #b0e0e6;">
				  <div class="row g-0" style="background-color:#e5e4e2;">
				    <div class="col-md-4 mt-5" style="background-color: #e5e4e2;">
				      <img src="images/<?php  echo $row['featured_image']; ?>"  style="height: 70%;" class="img-fluid rounded-start" alt="...">
				    </div>
				    <div class="col-md-8"  style="background-color:#e5e4e2;">
				      <div class="card-body " style="background-color:#e5e4e2;">
				        <h5 class="card-title" style="font-family: cursive; background-color:#50404d; color: white;"><?php echo $row['post_title']; ?></h5>
				        <p class="card-text"><?php echo $row['post_summary']; ?></p>
				      </div>
				    </div>
				  </div>
				</div>
				<?php
			}
			}

			?>
				
		</div>

		<!-- side portion Ends -->
	</div>

	<!-- Footer -->
	<?php
	include("include/footer.php");
	?>
	<!-- Footer Ends-->
	 <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>