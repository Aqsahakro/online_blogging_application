<?php

		require_once ("../require/connection.php");

	function getAllCommenntsInfo()
	{
		global $connection;
		$getAllCommentsQuery = "SELECT post.*,post_comment.*,user.`first_name`,user.`last_name`,user.`user_image` FROM `post_comment`
		INNER JOIN post
		ON `post_comment`.`post_id` = `post`.`post_id`
		INNER JOIN `user`
		ON `post_comment`.`user_id` = `user`.`user_id`
		ORDER BY `post_comment`.`post_comment_id`";

		$result = mysqli_query($connection,$getAllCommentsQuery);
		return $result;
	}
	function getCommentsByCommentId($post_comment_id)
	{
		global $connection;
		$get_comment = "SELECT * FROM `post_comment` WHERE `post_comment`.`post_comment_id` = $post_comment_id";
		$result = mysqli_query($connection,$get_comment);
		$data = mysqli_fetch_assoc($result);	
		return $data;
	}
	function editComment($action = "",$method="GET",$post_comment_id)
	{
		$data = getCommentsByCommentId($post_comment_id);
		?>
		<div class="card text-center m-5" style="background-color: #A8A8A8;">
			<div class="card-header bg-dark text-white">
			    Edit Comment
			</div>
			<div class="card-body text-center">
			<p class="card-text">
			<center>
			<form action="<?php echo $action; ?>" method="<?php echo $method; ?>">
			<input type="hidden" name="post_comment_id" value="<?php echo $data['post_comment_id'];?>">
			<center>
				<form action="comment-process.php" method="POST">
				<table>
					<tr>
						<th>Comment</th>
						<td>
							<input type="text" name="comment" required value="<?php echo $data['comment'];?>">
						</td>
					</tr>
					<tr>
						<th>User Name</th>
						<td>
							<input type="text" name="user_id" required value="<?php echo $data['first_name']." ".$data['last_name'];?>">
						</td>
					</tr>
					<tr>
						<th>Status: </th>
						<td>
						<select name="status">
							<option <?php if( $data['is_active'] == 'Active' ){echo "selected"; }else { echo '';}?> >Active</option>
							<option <?php if( $data['is_active'] == 'InActive' ){echo "selected"; }else { echo '';}?>>InActive</option>
						</select>
						</td>
					</tr>
					<tr>							
						<td align="center" colspan="2">
							<input type="submit" name="edit" value="Edit Comment">
						</td>
					</tr>
					</table>
				</form>
			</center>
			</p>
			</div>
			</div>
			<?php
	}

?>