<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		body{
			font-size: 20px;
		}
	</style>
	<script type="text/javascript">
		showAllUsersTable();
		function showAllUsersTable()
		{
			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					document.getElementById('show_all_users').innerHTML = obj.responseText;
				}
			}
		obj.open("GET",'user-process.php?action=show_users');
		obj.send();

		}
		function updateStatusActive(user_id)
		{

			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					showAllUsersTable();
					
				}
			}
		obj.open("GET",'user-process.php?action=active_status&user_id='+user_id);
		obj.send();
		}
		function updateStatusInActive(user_id)
		{
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					showAllUsersTable();
					
				}
			}
		obj.open("GET",'user-process.php?action=inactive_status&user_id='+user_id);
		obj.send();

		}
	</script>
</head>
<body>
	
	<?php
	require_once ("../require/connection.php");
	require_once 'session-maintaince.php';
	require_once ("manage-user-process.php");
	

	$user = getAllUsers();

	//including navBar
	include("include/header.php");
	?>

	<!-- Admin dashboard-->
	<div class="container-fluid">
	<div class="row">

		<!-- Side bar -->
		<?php
		include("include/sidebar.php");
		?>
		<!-- Side bar ends -->

		<!-- Add post Form -->
		<div class="col-10  col-sm-12 col-md-3 col-lg-10 text-black">
			<button type="button" class="btn btn-outline-secondary text-white m-2 bg-dark" style="float: right;" onclick="location.href='#view_users'">View All users</button>
			<div style="text-align: center; margin: 10px;">
			<?php 
					if( isset($_GET['message']) )
					{
					?>
						<p style="color: <?php echo $_GET['color']; ?>">
									
							<?php echo $_GET['message']; ?>
						</p>
					<?php
					}

					?>
			</div>
			<?php 

			if( isset($_GET['user_id']) )
			{
				EditFormUser("user-process.php","POST",$_GET['user_id']);
			}else{
				AddFormUser("user-process.php","POST");
			}

				
			?>
		<div class="container-fluid" id="show_all_users">
		</div>

	<!-- Footer -->
	<?php
	include("include/footer.php");
	?>
	<!-- Footer Ends-->
	 <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
	
	
</body>
</html>