<?php
	require_once '../require/connection.php';
	require_once("manage-category.php");
	$category = get_all_categories();

	if( isset(($_POST['add_category'])) )
	{
		extract($_POST);

		$insert_category_query = "INSERT INTO `category`(category_title, category_description, category_status)
								  VALUES(?,?,?)";

		$stmt = mysqli_prepare($connection,$insert_category_query);
		mysqli_stmt_bind_param($stmt,'sss',$category_title,$category_description,$status);

		if(mysqli_stmt_execute($stmt))
		{			
			$message = "Category Added Successfully!!";
			header("location: category.php?message=$message&color=green");	

		}
		else
		{
			$message = "Failed to Add Category!!";
			header("location: category.php?message=$message&color=red");
		}
	}
	if( isset(($_POST['update_category'])) )
	{
		extract($_POST);
		$update_category_query = "UPDATE `category` SET category_title=?, category_description=?, category_status=?
			WHERE category_id = ?";

		$stmt = mysqli_prepare($connection,$update_category_query);

		mysqli_stmt_bind_param($stmt,'sssi',$category_title,$category_description,$status,$category_id);

		if(mysqli_stmt_execute($stmt))
		{		
			$message = "Category Updated Successfully!!";
			header("location: category.php?message=$message&color=green");	

		}
		else
		{
			$message = "Failed to Update Category Information!";
			header("location: category.php?message=$message&color=red");
		}

	}
	if ( isset($_REQUEST['action']) && $_REQUEST['action'] == 'show_category' )
	{ ?>
		<div class="row">
		<div class="col-12" id="view_users">
		<div class="card text-center" align="center" style="width:100%; margin-top: 20px;">
			<div class="card-header bg-dark text-white" style="width:100%;">
			    All Categories
			</div>
			<p>
	
			</p>
			<div class="card-body" style="width:100%;">
			  	<table class="table table-striped">
			  	<thead class="thead">
			   	<tr>
			   		<th>Category Title</th>
			   		<th>Category Description</th>
			   		<th>Category Status</th>
			   		<th>Actions</th>
			   	</tr>
			   	</thead>
			   	 	<?php

					if( $category->num_rows > 0 )
					{
						while( $row = mysqli_fetch_assoc($category) )
						{
						?>
						<tr>
						<td>
							<?php echo $row['category_title']; ?>		
						</td>
						<td>
							<?php echo $row['category_description']; ?>		
						</td>
						<td>
							<?php echo $row['category_status']; ?>		
						</td>
						 <td>
						<a href="javascript:void(0)" class="btn bg-dark " category_id="<?php echo $row['category_id']; ?>" onclick="update_status_active(<?php echo $row['category_id']; ?>)" role="button" aria-disabled="true" style = "color: white;"  >Active
						</a>
						<a href="javascript:void(0)" class="btn bg-dark m-2 " category_id="<?php echo $row['category_id']; ?>" onclick="update_status_inactive(<?php echo $row['category_id']; ?>)" role="button" aria-disabled="true" style = "color: white;"  >InActive
						</a>
						</td>
						<td>
						<a href="category.php?category_id=<?php echo $row['category_id']; ?>"  class="btn bg-dark" tabindex="-1" role="button" aria-disabled="true" style = "color: white; background-color:black;">Update</a></td>
						</tr>
						<?php
						}
					}

			   		?>
			   	</table>
			</div>
			</div>
		</div>
		</div>
	<?php
	}
	if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'active_status')
	{

	 	$update_query = "UPDATE `category` SET category_status = 'Active' 
	 	WHERE category_id = ".$_REQUEST['category_id'];

	 	$result = mysqli_query($connection,$update_query);

	 	$select_query = "SELECT * FROM category";


	 	$select_result = mysqli_query($connection,$select_query);	
	}

	if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'inactive_status')
	{

	 	$update_query = "UPDATE `category` SET category_status = 'InActive' 
	 	WHERE category_id = ".$_REQUEST['category_id'];

	 	$result = mysqli_query($connection,$update_query);

	 	$select_query = "SELECT * FROM category";


	 	$select_result = mysqli_query($connection,$select_query);	
	}

?>