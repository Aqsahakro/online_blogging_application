<?php

	require_once ("../require/connection.php");

	function getAllBlogs()
	{
		global $connection;
		$getAllBlogsQuery = "SELECT * FROM `blog` ORDER BY `blog`.`blog_id` DESC";
		$result = mysqli_query($connection,$getAllBlogsQuery);
		return $result;
	}
	function getBlogsByBlogId($blog_id)
	{
		global $connection;
		$get_blog = "SELECT * FROM `blog` WHERE `blog`.`blog_id` = $blog_id";
		$result = mysqli_query($connection,$get_blog);
		$data = mysqli_fetch_assoc($result);	
		return $data;
	}
	function addBlogForm($action = "",$method="GET")
	{
	?>
		<!-- Add Blog form -->
		<div class="card text-center m-5" style="background-color: #A8A8A8; height: 500px;">
			<div class="card-header bg-dark text-white">
			    Create Blog
			</div>
			<div class="card-body text-center m-5" style="text-align: center;">
			    <p class="card-text" style="text-align: center;">
			    <center>
			    <form action="blog-process.php" method="POST">
				<table >
					<tr>
						<th>blog Title</th>
						<td>
							<input type="text" name="blog_title" required>
						</td>
					</tr>
					<br>
					<tr>
						<th>Post per page</th>
						<td>
							<input type="text" name="post_per_page" required>
						</td>
					</tr>
					<tr>
						<th>blog Status: </th>
						<td>
						<select name="status">
						<option value="none" selected disabled hidden>Select an Option</option>
							<option>Active</option>
							<option>Inactive</option>
						</select>
						</td>
					</tr>
					<tr>
						<th>Background Image</th>
						<td>
							<input type="file" name="image" accept="image/png, image/jpeg" required>
						</td>
					</tr>
					<tr>							
						<td align="center" colspan="2" >
							<input type="submit" name="add_blog" value="Add Blog" >
						</td>
					</tr>
				</table>
				</form>
				</center>
			</div>
		</div> 
		<?php
		}

	function editBlogForm($action = "",$method="GET",$blog_id)
	{
		$data = getBlogsByBlogId($blog_id);
		?>
		<div class="card text-center m-5" style="background-color: #A8A8A8;">
			<div class="card-header bg-dark text-white">
			    Update Blog
			</div>
			<div class="card-body text-center">
			<p class="card-text">
			<center>
			<form action="<?php echo $action; ?>" method="<?php echo $method; ?>">
			<input type="hidden" name="blog_id" value="<?php echo $data['blog_id'];?>">
			<center>
				<form action="blog-process.php" method="POST">
				<table>
					<tr>
						<th>Blog Title</th>
						<td>
							<input type="text" name="blog_title" required value="<?php echo $data['blog_title'];?>">
						</td>
					</tr>
					<tr>
						<th>Post per page</th>
						<td>
							<input type="text" name="post_per_page" required value="<?php echo $data['post_per_page'];?>">
						</td>
					</tr>
					<tr>
						<th>blog Status: </th>
						<td>
						<select name="status">
							<option <?php if( $data['blog_status'] == 'Active' ){echo "selected"; }else { echo '';}?> >Active</option>
							<option <?php if( $data['blog_status'] == 'InActive' ){echo "selected"; }else { echo '';}?>>InActive</option>
						</select>
						</td>
					</tr>
					<tr>
						<th>Background Image</th>
						<td>
							<input type="file" name="image" accept="image/png, image/jpeg" required>
						</td>
					</tr>
					<tr>							
						<td align="center" colspan="2">
							<input type="submit" name="update_blog" value="Update Blog">
						</td>
					</tr>
				</table>
				</form>
			</center>
			</p>
			</div>
			</div>
			<?php
	}
?>