<?php
	require_once '../require/connection.php';

	function get_all_categories()
	{
		global $connection;
		$query = "SELECT * FROM category ORDER BY category_id DESC";
		$result = mysqli_query($connection,$query);
		return $result;
	}
	function get_category_by_Id($category_id)
	{
		global $connection;
		$query = "SELECT * FROM `category` WHERE `category`.`category_id` = $category_id";
		$result = mysqli_query($connection,$query);
		$data = mysqli_fetch_assoc($result);	
		return $data;
	}
	function add_category_form($action = "",$method="GET")
	{
		?>
		<div class="card text-center m-5" style="background-color: #A8A8A8; height: 500px;" >
			  <div class="card-header bg-dark text-white" style="text-align: center;">
			    Add Categories
			  </div>
			  <div class="card-body text-center" style="text-align: center;">
			    <p class="card-text " style="text-align: center;">
			    <center>
			    <form method="POST" action="category-process.php">
				<table style="margin-top: 50px;">
					<tr>
						<th>Category Tittle:</th>
						<td>
							<input type="text" name="category_title" required>
						</td>
					</tr>
					<br>
					<tr>
						<th>Category Description:</th>
						<td>
							<input type="text" name="category_description" required>
						</td>
					</tr>
					<tr>
						<th>Category Status: </th>
						<td>
							<select name="status">
							<option value="none" selected disabled hidden>Select an Option</option>
							<option>Active</option>
							<option>Inactive</option>
							</select>
							</td>
					</tr>
					<tr>							
						<td align="center" colspan="2" >
							<input type="submit" name="add_category" value="Add Category" >
						</td>
					</tr>
					</table>
				</form>
				</center>
			  </div>
			</div> 

			<?php
		}
		function edit_category_form($action = "",$method="GET",$category_id)
		{

		$category = get_category_by_Id($category_id)
		?>
		<div class="card text-center m-5" style="background-color: #A8A8A8; height: 500px;">
			<div class="card-header bg-dark text-white" style="text-align: center;">
			    Update Categories
			 </div>
		 <div class="card-body text-center" style="text-align: center;">
			<p class="card-text">
			<center>
		  	<form action="<?php echo $action; ?>" method="<?php echo $method; ?>">
			<input type="hidden" name="category_id" value="<?php echo $category['category_id'];?>">
			<center>
			    <form action="category-process.php" method="POST">
				<table style="margin-top: 50px;">
					<tr>
						<th>Category Tittle:</th>
						<td>
							<input type="text" name="category_title" required value="<?php echo $category['category_title'];?>">
						</td>
					</tr>
					<br>
					<tr>
						<th>Category Description:</th>
						<td>
							<input type="text" name="category_description" required value="<?php echo $category['category_description'];?>">
						</td>
					</tr>
					<tr>
						<th>Category Status:</th>
						<td>
							<select name="status">
							<option <?php if( $category['category_status'] == 'Active' ){echo "selected"; }else { echo '';}?> >Active</option>
							<option <?php if( $category['category_status'] == 'InActive' ){echo "selected"; }else { echo '';}?>>Inactive</option>
							</select>
					</tr>
					<tr>							
						<td align="center" colspan="2">
							<input type="submit" name="update_category" value="Update Category">
						</td>
					</tr>
					</table>
				</form>
				</center>
			    </p>
			  </div>
			</div>
			 <?php

	}



?>