<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<?php


	require_once ("../require/connection.php");
	require_once 'session-maintaince.php';
	require_once ("manage-blog.php");

	$blogs = getAllBlogs();

	include("include/header.php");

	?>
	<div class="container-fluid">
	<div class="row">

	<!-- Side bar -->
	<?php
		include("include/sidebar.php");
	?>
	<!-- Side bar ends -->

	<!-- Add post Form -->
		<div class="col-10 col-sm-12 col-md-10 col-lg-10  text-black">
			<button type="button" class="btn btn-outline-secondary text-white m-2 bg-dark" style="float: right;" onclick="location.href='#view_blogs'">View All Blogs</button>
			<div style="text-align: center; margin: 10px;">
			<?php 
					if( isset($_GET['message']) )
					{
					?>
						<p style="color: <?php echo $_GET['color']; ?>">
									
							<?php echo $_GET['message']; ?>
						</p>
					<?php
					}

					?>
			</div>
			<?php 

			if( isset($_GET['blog_id']) )
			{
				editBlogForm("blog-process.php","POST",$_GET['blog_id']);
			}else{
				addBlogForm("blog-process.php","POST");
			}
			?>

		<div class="container-fluid">
		<div class="row">
		<div class="col-12 col-sm-12 col-md-10 col-lg-10 " id="view_blogs">
		<div class="card text-center" align="center" style="width:100%; margin-top: 5%;">
			<div class="card-header bg-dark text-white" style="width:100%;">
			    All Blogs
			</div>
			<p>
					<?php 
						if(isset($_GET['message']))
						{
							?>
								<p style="color: <?php echo $_GET['color']; ?>">
									
									<?php echo $_GET['message']; ?>
								</p>
							<?php
						}

					?>
			</p>
			<div class="card-body" style="width:100%;">
			  	<table class="table table-striped">
			  	<thead class="thead">
			   	<tr>
			   		<th>Blog Id</th>
			   		<th>Blog Title</th>
			   		<th>Post per page</th>
			   		<th>Blog status</th>
			   		<th>Background Image</th>
			   	</tr>
			   	</thead>
			   	<?php
			   		require_once ("../require/connection.php");

					if( $blogs->num_rows > 0 )
					{
						while( $row = mysqli_fetch_assoc($blogs) )
						{
						?>
						<tr>
						<td>
							<?php echo $row['blog_id']; ?>		
						</td>
						<td>
							<?php echo $row['blog_title']; ?>		
						</td>
						<td>
							<?php echo $row['post_per_page']; ?>		
						</td>
						<td>
							<?php echo $row['blog_status']; ?>		
						</td>
						<td>
							<img src="images/<?php echo $row['blog_background_image'];?>" style="width: 50%;">		
						</td>
						<td>
							<a href="create-blog.php?blog_id=<?php echo $row['blog_id']; ?>"  class="btn" tabindex="-1" role="button" aria-disabled="true" style = "color: white; background-color:black;">Update</a>

							<a href="javascript:void(0)" blog_id="<?php echo $row['blog_id']; ?>" onclick="deletePost(this)" class="btn m-2" tabindex="-1" role="button" aria-disabled="true" style = "color: white; background-color:black; ">Delete</a>		
						</td>
						</tr>
						<?php
						}
					}
			   		?>
			   	</table>
			</div>
		</div>
		</div>
		</div>
		</div>

	<!-- Footer -->
	<?php
	include("include/footer.php");
	?>
	<!-- Footer Ends-->

	 <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>
