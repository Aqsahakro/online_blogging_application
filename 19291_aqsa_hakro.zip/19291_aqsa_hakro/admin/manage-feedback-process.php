<?php
	require_once ("../require/connection.php");

	function getAllFeedbacks()
	{
		global $connection;
		$getAllFeedbacksQuery = "SELECT * FROM `user_feedback`
								ORDER BY `user_feedback`.feedback_id  DESC";

		$result = mysqli_query($connection,$getAllFeedbacksQuery);
		return $result;
	}


?>