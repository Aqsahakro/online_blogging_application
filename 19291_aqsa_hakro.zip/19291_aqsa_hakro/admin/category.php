<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<script type="text/javascript">
		show_all_categories();
		function show_all_categories()
		{
			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					document.getElementById('show_all_categories').innerHTML = obj.responseText;
				}
			}
		obj.open("GET",'category-process.php?action=show_category');
		obj.send();
		}
		function update_status_active(category_id)
		{

			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					show_all_categories();
					
				}
			}
		obj.open("GET",'category-process.php?action=active_status&category_id='+category_id);
		obj.send();
		}
		function update_status_inactive(category_id)
		{

			var obj;
			if (window.XMLHttpRequest) {
				obj = new XMLHttpRequest();
			}else{
				obj = new ActiveXObject("Microsoft.XMLHTTP");
			}
			obj.onreadystatechange = function()
			{
				if (obj.readyState == 4 && obj.status == 200) {
					show_all_categories();
					
				}
			}
		obj.open("GET",'category-process.php?action=inactive_status&category_id='+category_id);
		obj.send();
		}
	</script>
</head>
<body>
	<?php
	include("include/header.php");
	require_once("manage-category.php");
	?>

	<div class="container-fluid">
	<div class="row">

	<!-- Side bar -->
	<?php
		include("include/sidebar.php");
	?>
	<!-- Side bar ends -->

	<div class="col-10 col-sm-12 col-md-10 col-lg-10 text-black">
		<button type="button" class="btn btn-outline-secondary text-white m-2 bg-dark" style="float: right;" onclick="location.href='#view_users'">View All Categories
		</button>
		<div style="text-align: center; margin: 10px; margin-top: 5%;">
			<?php 
					if( isset($_GET['message']) )
					{
					?>
						<p style="color: <?php echo $_GET['color']; ?>">
									
							<?php echo $_GET['message']; ?>
						</p>
					<?php
					}

					?>
			</div>
			<?php 
			$category = get_all_categories();

			if( isset($_GET['category_id']) )
			{
				edit_category_form("category-process.php","POST",$_GET['category_id']);
			}else{
				add_category_form("category-process.php","POST");
			}	
			?>
		<div class="container-fluid" id="show_all_categories">
		</div>

	<!-- Footer -->
	<?php
	include("include/footer.php");
	?>
	<!-- Footer Ends-->
	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>


</body>
</html>