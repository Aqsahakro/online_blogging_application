<?php
	require_once '../require/connection.php';
	require_once ("manage-user-process.php");
	

	$user = getAllUsers();

	if( isset(($_POST['add_user'])) )
	{
		extract($_POST);

		$role_id = 2;
		$insert_user_query = "INSERT INTO `user`(role_id,first_name,last_name,email,password,phone_number,gender,date_of_birth,user_image,address,is_active)
		VALUES(?,?,?,?,?,?,?,?,?,?)";
		$stmt = mysqli_prepare($connection,$insert_user_query);
		mysqli_stmt_bind_param($stmt,'ssssssssss',$role_id,$first_name,$last_name,$email,$password,$number,$gender,$dob,$image,$address,$status);

		if(mysqli_stmt_execute($stmt))
		{			
			$message = "User Added Successfully!!";
			header("location: manage-users.php?message=$message&color=green");	

		}
		else
		{
			$message = "Failed to Add user!!";
			header("location: manage-users.php?message=$message&color=red");
		}
	}
	if( isset(($_POST['update_user'])) )
	{
		extract($_POST);
		$update_user_query = "UPDATE `user` SET first_name=?,last_name=?,email=?,password=?,phone_number=?,gender=?,date_of_birth=?,user_image=?,address=?,is_active=?
			WHERE user_id = ?";

		$stmt = mysqli_prepare($connection,$update_user_query);

		mysqli_stmt_bind_param($stmt,'ssssssssssi',$first_name,$last_name,$email,$password,$number,$gender,$dob,$image,$address,$status,$user_id);

		if(mysqli_stmt_execute($stmt))
		{		
			$message = "User Updated Successfully!!";
			header("location: manage-users.php?message=$message&color=green");	

		}
		else
		{
			$message = "Failed to Update User Information!";
			header("location: manage-users.php?message=$message&color=red");
		}

	}
	if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'show_users')
	{ ?>
		<div class="row">
		<div class="col-12" id="view_users">
		<div class="card text-center" align="center" style="width:100%; margin-top: 20px;">
			<div class="card-header bg-dark text-white" style="width:100%;">
			    All Users
			</div>
			<p>
	
			</p>
			<div class="card-body" style="width:100%;">
			  	<table class="table table-striped">
			  	<thead class="thead">
			   	<tr>
			   		<th>User Image</th>
			   		<th>User Id</th>
			   		<th>Full Name</th>
			   		<th>Email</th>
			   		<th>Password</th>
			   		<th>Contact Number</th>
			   		<th>Gender</th>
			   		<th>Date of Birth</th>
			   		<th>Home Town</th>
			   		<th>Status</th>
			   		<th>Actions</th>
			   		<th>Update User</th>
			   		
			   	</tr>
			   	</thead>
			   	 	<?php

					if( $user->num_rows > 0 )
					{
						while( $row = mysqli_fetch_assoc($user) )
						{
						?>
						<tr>
						<td>
							<img src="images/<?php echo $row['user_image'];?>" style="width: 50px; border-radius: 50%;">
						</td>
						<td>
							<?php echo $row['user_id']; ?>		
						</td>
						<td>
							<?php echo $row['first_name']." ".$row['last_name']; ?>		
						</td>
						<td>
							<?php echo $row['email']; ?>		
						</td>
						<td>
							<?php echo $row['password']; ?>		
						</td>
						<td>
							<?php echo $row['phone_number']; ?>		
						</td>
						<td>
							<?php echo $row['gender']; ?>		
						</td>
						<td>
							<?php echo $row['date_of_birth']; ?>		
						</td>
						<td>
							<?php echo $row['address']; ?>		
						</td>
						<td>
							
							<?php echo $row['is_active']; ?>		
						</td>

						 <td>
						<a href="javascript:void(0)" class="btn bg-dark " user_id="<?php echo $row['user_id']; ?>" onclick="updateStatusActive(<?php echo $row['user_id']; ?>)" role="button" aria-disabled="true" style = "color: white;"  >Active
						</a>
						<a href="javascript:void(0)" class="btn bg-dark m-2 " user_id="<?php echo $row['user_id']; ?>" onclick="updateStatusInActive(<?php echo $row['user_id']; ?>)" role="button" aria-disabled="true" style = "color: white;"  >InActive
						</a>
						</td> 

						<td>
						<a href="manage-users.php?user_id=<?php echo $row['user_id']; ?>"  class="btn bg-dark" tabindex="-1" role="button" aria-disabled="true" style = "color: white; background-color:black;">Update</a></td>
						</tr>
						<?php
						}
					}

			   		?>
			   	</table>
			</div>
			</div>
		</div>
		</div>
	<?php
	}

	if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'active_status')
	{

	 	$update_query = "UPDATE `user` SET is_active = 'Active' 
	 	WHERE user_id = ".$_REQUEST['user_id'];

	 	$result = mysqli_query($connection,$update_query);

	 	$select_query = "SELECT * FROM user";


	 	$select_result = mysqli_query($connection,$select_query);	
	}

	if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'inactive_status')
	{

	 	$update_query = "UPDATE `user` SET is_active = 'InActive' 
	 	WHERE user_id = ".$_REQUEST['user_id'];

	 	$result = mysqli_query($connection,$update_query);

	 	$select_query = "SELECT * FROM user";


	 	$select_result = mysqli_query($connection,$select_query);	
	}

?>