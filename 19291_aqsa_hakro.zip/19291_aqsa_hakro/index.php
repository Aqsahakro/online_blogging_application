<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Blogging Application</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<!-- Header -->
	<?php
	require_once ("require/connection.php");
	include("include/header.php");
	include("include/navbar.php");
	?>
	<!-- Header Ends -->

	<!-- Content-->
	<div class="row m-3">
		<div class="col-8 col-sm-12 col-md-3 col-lg-8 text-center"> 
			<h2><b>POSTS</b></h2>
			<?php 
				$post_query = "SELECT * FROM post 
							   ORDER BY post_id DESC
							   LIMIT 7";

				$result = mysqli_query($connection,$post_query);

				if ( $result-> num_rows > 0 )
			 	{
					while( $row = mysqli_fetch_assoc($result) )
					{ ?>

			<div class="card mb-3">
				<div class="card-header text-white" style="font-family: cursive; background-color:#50404d; font-size: 20px;"><?php  echo $row['post_title']; ?></div>
				<img src="images/<?php  echo $row['featured_image']; ?>"  style="height: 100%;" class="img-fluid rounded-start" alt="...">
				<div class="card-body">
					<p class="card-text"><?php  echo $row['post_summary']; ?></p>
				</div>
			</div>
			<?php 
					} 
				} ?>
		</div>


		<div class="col-3 col-sm-12 col-md-3 col-lg-3 text-center">
			<div class="row">
			<h2 style="margin-top: 50px;"><b>TOP STORIES</b></h2>
			</div>
			<div class="row">
			<?php
				$get_post_query = "SELECT * FROM post 
									LIMIT 5";
				$result = mysqli_query($connection,$get_post_query);

				if ( $result-> num_rows > 0 )	
		 		{
					while( $row = mysqli_fetch_assoc($result) )
					{ ?> 
					<div class="card m-5" style="max-width: 450px;" style="margin:10%; text-align: center; background-color: #b0e0e6;">
					 	<div class="row g-0" style="background-color:#e5e4e2;">
					    <div class="col-md-4 mt-5" style="background-color: #e5e4e2;">
					      	<img src="images/<?php  echo $row['featured_image']; ?>"  style="height: 70%;" class="img-fluid rounded-start" alt="...">
					    </div>
					    <div class="col-md-8"  style="background-color:#e5e4e2;">
						    <div class="card-body " style="background-color:#e5e4e2;">
						        <h5 class="card-title" style="font-family: cursive; background-color:#50404d; color: white;"><?php echo $row['post_title']; ?></h5>
						        <p class="card-text" style="font-size: 18px;"><?php echo $row['post_summary']; ?></p>
						    </div>
					    </div>
					  	</div>
					</div>
					<?php
					}
				}?>
			</div>
		</div>

		<div class="row m-3">
			<center><h2 style="margin-top: 50px;"><b>Categories</b></h2></center>
			<?php
				$category_query = "SELECT * FROM category";
				$category = mysqli_query($connection,$category_query);

				if ( $category-> num_rows > 0 )
		 		{
					while( $row = mysqli_fetch_assoc($category) )
					{ ?> 
					<div class="card text-bg-light m-3" style="max-width: 18rem;">
						<div class="card-header m-2 mb-3" style="font-family: cursive; background-color:#50404d; color: white; font-size: 25px;" ><?php  echo $row['category_title']; ?></div>
						<div class="card-body">
					    <p class="card-text" style="font-size: 18px;"><?php  echo $row['category_description']; ?></p>
						</div>
					</div>
					<?php
					}
				}?>
		</div>

    <!-- Footer -->
    <?php
    include("include/footer.php");
    ?>
    <!-- Footer -->

	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script> +
</body>
</html>