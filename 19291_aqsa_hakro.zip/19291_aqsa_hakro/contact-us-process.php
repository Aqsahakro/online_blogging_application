<?php
	require_once("require/connection.php");

	if( isset($_POST['send']) )
	{
		extract($_POST);

		$insertQuery = "INSERT INTO `user_feedback` (user_name,user_email,feedback)
			VALUES (?,?,?)";

		$stmt = mysqli_prepare($connection,$insertQuery);

		mysqli_stmt_bind_param($stmt,'sss',$full_name,$email,$comment);

		$message = "";
		if(mysqli_stmt_execute($stmt))
		{
			$message = "Message Sent Successfully!!";
			header("location: contact-us.php?message=$message&color=green");
		}
		else
		{
			$message = "Sorry your Message failed to send!!";
			header("location: contact-us.php?message=$message&color=red");

		}

	}

?>