<?php
	
	require_once("require/connection.php");
	// require_once 'session-maintaince.php';
	// echo "<pre>";
	// print_r($connection);
	// echo "</pre>";
	// die;
	
	if (isset($_POST['register']))
	{
			//Setting Patterns
			$fname_pattern    =   "/^[A-Z]{1}[a-z]{2,}$/";
			$lname_pattern    =   "/^[A-Z]{1}[a-z]{2,}$/";
			$email_pattern    =   "/^[a-z]{2,}[0-9]{2,}[@]{1}[a-z]{2,}[.]{1}[a-z]{3,}$/";
			$password_pattern =   "/^[a-zA-Z]{7}[0-9]{1}$/";
			$phone_pattern 	  =   "/^[92]{2}[0-9]{3}[0-9]{7}$/";

			extract($_REQUEST);

			$flag = true;
			$message = "";

		//first_name condition
		if( $first_name == "" )
		{
			echo $message .= "<li>First Name is Required</li>";
			$flag = false;
		}
		else
		{
		 	if ( !preg_match($fname_pattern, $first_name) )
				{
				    $message .= "<li>Name must be like: e.g.James <li/>";
					$flag = false;

				}
		}

		//last_name condition
		if( $last_name == "" )
		{
			echo $message .= "<li>last Name is Required</li>";
			$flag = false;
		}
		else
		{
		 	if ( !preg_match($lname_pattern, $last_name) )
				{
				    $message .= "<li>Last Name must be like: e.g.Walker <li/>";
					$flag = false;

				}
		}

		//email condition
		if( $email == "" )
		{
			echo $message .= "<li>Email is Required</li>";
			$flag = false;
		}
		else
		{
		 	if ( !preg_match($email_pattern, $email) )
				{
				    $message .= "<li>Email must be like: e.g.jameswalker12@gmail.com<li/>";
					$flag = false;

				}
		}

		//password condition
		if( $password == "" )
		{
			echo $message .= "<li>Password is Required</li>";
			$flag = false;
		}
		else
		{
		 	if ( !preg_match($password_pattern, $password) )
				{
				    $message .= "<li>Password must contain atleast 8 characters and a number<li/>";
					$flag = false;

				}
		}

		//phone_number condition
		if( $number == "" )
		{
			echo $message .= "<li>Phone Number is Required</li>";
			$flag = false;
		}
		else
		{
		 	if ( !preg_match($phone_pattern, $number) )
				{
				    $message .= "<li>Number must be like: e.g.923020643286<li/>";
					$flag = false;

				}
		}

		if( $dob == "" )
		{
			echo $message .= "<li>Date of Birth is Required</li>";
			$flag = false;
		}

		if( $address == "" )
		{
			echo $message .= "<li>Address is Required</li>";
			$flag = false;
		}

		if(!isset($gender))
		{
			echo $message .= "<li>Gender is Required</li>";
			$flag = false;
		}

		if( $image == "" )
		{
			echo $message .= "<li>Image is Required</li>";
			$flag = false;
		}
	}
	if ( $flag == false ) {
		header("location: register.php?message=".$message);
	}
	else
	{
		extract($_POST);
		$role_id = 2;
		$insert_query = "INSERT INTO `user`(role_id,first_name,last_name,email,password,phone_number,date_of_birth,address,gender,user_image)
		VALUES(?,?,?,?,?,?,?,?,?,?)";

		$insert_stmt = mysqli_prepare($connection,$insert_query);

		mysqli_stmt_bind_param($insert_stmt,'isssssssss',$role_id,$first_name,$last_name,$email,$password,$number,$dob,$address,$gender,$image);

		$msg = "";

		if(mysqli_stmt_execute($insert_stmt))
		{

			$user_last_insert_id =  mysqli_insert_id($connection);
			//$msg = "User Account Registered With User Id:".$user_last_insert_id;
			$message = "User Account Registered Sucessfully";
			header("location: register.php?message=$message&color=green");	

		}	
	 	else
		{
			$message = "Sorry!! you are not Registered.";
			header("location: register.php?message=$message&color=red");
		}



		// $insert_query = "INSERT INTO `user`(role_id,first_name,last_name,email,password,phone_number,date_of_birth,address,gender,user_image)
		//  VALUES('".$role_id."','".$first_name."','".$last_name."','".$email."','".$password."','".$number."','".$dob."','".$address."','".$gender."','".$image."'')";

		//  $result = mysqli_query($connection,$insert_query);
		
		//  $message = "";

		// if($result)
		// {

			
		// 	$message = "User Account Registered Sucessfully";
		// 	header("location: register.php?message=$message&color=green");	

		// }	
	 // 	else
		// {
		// 	$message = "Sorry!! you are not Registered.";
		// 	header("location: register.php?message=$message&color=red");
		// }


	}


?>