<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Register Page</title>
	<style type="text/css">
		body{
			font-family: sans-serif;
			font-size: 20px;
		}
		span{
			color: red;
		}
		li{
			color: red;
			list-style: none;
		}
	</style>
	<script type="text/javascript">
		function form_validation()
		{
			//setting the patterns
			var fname_pattern    =   /^[A-Z]{1}[a-z]{2,}$/;
			var lname_pattern    =   /^[A-Z]{1}[a-z]{2,}$/;
			var email_pattern    =   /^[a-z]{2,}[0-9]{2,}[@]{1}[a-z]{2,}[.]{1}[a-z]{3,}$/;
			var password_pattern =   /^[a-zA-Z]{7}[0-9]{1}$/;
			var phone_pattern 	 =   /^[92]{2}[0-9]{3}[0-9]{7}$/;



			//getting data from registration form
			var first_name 	  		=  document.getElementById("first_name").value;
			var last_name    		=  document.getElementById("last_name").value;
			var email         		=  document.getElementById("email").value;
			var password         	=  document.getElementById("password").value;
			var phone_number        =  document.getElementById("phone_number").value;
			var address             =  document.getElementById("address").value;
			var image             	=  document.getElementById("image").value;
			var dob             	=  document.getElementById("dob").value;


			var male = document.getElementById('male');
			var female = document.getElementById('female');

			var gender = "";
			if(male.checked)
			{
				gender = male.value;
			}
			else if(female.checked)
			{
				gender = female.value;
			}



			//message variables
			var first_name_msg	 	= document.getElementById('first_name_msg');
			var last_name_msg 	 	= document.getElementById('last_name_msg');
			var email_msg      	  	= document.getElementById('email_msg');
			var password_msg        = document.getElementById('password_msg');
			var phone_num_msg       = document.getElementById('number_msg');
			var gender_msg          = document.getElementById('gender_msg');
			var address_msg         = document.getElementById('address_msg');
			var image_msg           = document.getElementById('image_msg');
			var dob_msg           	= document.getElementById('dob_msg');



			//setting the conditions
			var flag = true;

			//first_name condition
			if ( first_name == "" ) {
				first_name_msg.innerHTML = " First Name is Required";
				flag = false;
			}
			else if( fname_pattern.test(first_name) == false )
			{
				first_name_msg.innerHTML = "Name must be like: e.g.James";
				flag = false;
			}
			else
			{
				first_name_msg.innerHTML = "";
			}

			//last_name condition
			if ( last_name == "" ) {
				last_name_msg.innerHTML = " Last Name is Required";
				flag = false;
			}
			else if( lname_pattern.test(last_name) == false )
			{
				last_name_msg.innerHTML = "Last name must be like: e.g.Walker";
				flag = false;
			}
			else
			{
				last_name_msg.innerHTML = "";
			}

			//email condition
			if ( email == "" ) {
				email_msg.innerHTML = " Email is Required";
				flag = false;
			}
			else if( email_pattern.test(email) == false )
			{
				email_msg.innerHTML = "Email must be like: e.g.jameswalker12@gmail.com";
				flag = false;
			}
			else
			{
				email_msg.innerHTML = "";
			}

			//password condition
			if ( password == "" ) {
				password_msg.innerHTML = " Password is Required";
				flag = false;
			}
			else if( password_pattern.test( password ) == false )
			{
				password_msg.innerHTML = "Password must contain atleast 8 characters and a number";
				flag = false;
			}
			else
			{
				password_msg.innerHTML = "";
			}

			//phone_number condition
			if ( phone_number == "" ) {
				phone_num_msg.innerHTML = "Phone Number is Required";
				flag = false;
			}
			else if( phone_pattern.test( phone_number ) == false )
			{
				phone_num_msg.innerHTML = "Number must be like: e.g.923020643286";
				flag = false;
			}
			else
			{
				phone_num_msg.innerHTML = "";
			}

			//Gender condition
			if ( gender == "" ) {
				gender_msg.innerHTML = "Gender is Required";
				flag = false;
			}
			else if( gender )
			{
				gender_msg.innerHTML = "";
			}

			//Address condition
			if ( address == "" ) {
				address_msg.innerHTML = "Address is Required";
				flag = false;
			}
			else
			{
				address_msg.innerHTML = "";
			}

			//Image condition
			if ( image == "" ) {
				image_msg.innerHTML = "Image is Required";
				flag = false;
			}
			else
			{
				image_msg.innerHTML = "";
			}

			//dob condition
			if ( dob == "" ) {
				dob_msg.innerHTML = "date of Birth is Required";
				flag = false;
			}
			else
			{
				dob_msg.innerHTML = "";
			}


			if( flag )
				return true;
			else 
				return false;

		}

	</script>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<?php
	require_once 'session-maintaince.php';
	require_once("require/connection.php");
	include("include/header.php");
	include("include/navbar.php");
	
	?>
	<!-- Login form -->
	<center>
		<div class="card text-center">
		  <div class="card-header m-5 bg-secondary">
		    	<b><h2>Registration Form</h2></b>
		  </div>
		  	<div>
			</div>
		  <div class="card-body">
		  	<form action="registration-process.php"  method="POST" onsubmit="return form_validation()">
		  					<center>
		  						<p style="color:black; text-align: center;"><b>Note:Marked (*) Fields are required !!</b></p>
							<table>
								 <?php
								  if (isset($_REQUEST['message'])) {
									      echo "<ul>";
									       echo $_REQUEST['message'];
									      echo "</ul>";
								} ?> 
							
							<tr>
								<td>First Name: <span>*</span></td>
								<td><input type="name" name="first_name" id="first_name" >
								<span id="first_name_msg"></span></td>
							</tr>
							<tr>
								<td>Last Name: <span>*</span></td>
								<td><input type="name" name="last_name" id="last_name" >
								<span id="last_name_msg"></span></td>
							</tr>
							<tr>
								<td>Email: <span>*</span> </td>
								<td><input type="email" name="email" id="email" >
								<span id="email_msg"></span></td>
							</tr>
							<tr>
								<td>Password: <span>*</span></td>
								<td><input type="password" name="password" id="password" >
								<span id="password_msg"></span></td>
							</tr>
							<tr>

								<td>Phone Number: <span>*</span></td>
								<td><input type="text" name="number" id="phone_number" >
								<span id="number_msg"></span></td>
							</tr>
							<tr>
								<td>Date of Birth: <span>*</span></td>
								<td><input type="Date" name="dob" id="dob" >
								<span id="dob_msg"></span></td>
							</tr>
							<tr>
								<td>Home Town: <span>*</span> </td>
								<td><input type="text" name="address" id="address" >
								<span id="address_msg"></span></td>
							</tr>
							<tr>
								<td>Gender: <span>*</span></td>
								<td>
								Male <input type="radio" name="gender" value="Male"  id="male" > || 
								Female <input type="radio" name="gender" value="Female" id="female">
								<span id="gender_msg"></span></td>
							</tr>
							<tr>
								<td>Image: <span>*</span></td>
								<td>
								<input type="file" name="image" id="image" accept="image/png, image/jpeg" />
								<span id="image_msg"></span></td>
							</tr>
							<br>

							<tr>
								<td colspan="2" align="center">
									<input type="submit" name="register" value="Register" style="margin-top:10px; width: 300px;" onclick="return form_validation()">
									<br>
									<br>
									<h6 style="color: darkblue;">Already have an account? <a href="login.php" style=" color:black;">Sign In</a></h6>
								</td>
							</tr>
							</table>
							</center>	
						</form>
		  </div>
		</div>
	<!-- Login form Ends -->

	<?php
	include("include/footer.php");
	?>
	
	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

</center>
</body>
</html>