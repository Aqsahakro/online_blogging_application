<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Feedback Page</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<?php
	include("include/header.php");
	include("include/navbar.php");

	?>
	<div class="Feedback m-3 " style="text-align: center; font-weight: bold; font-size: 30px;">
			<?php 
				if( isset($_GET['message']) )
				{
					?>
						<p style="color: <?php echo $_GET['color']; ?>">
							
							<?php echo $_GET['message']; ?>
						</p>
					<?php
				}

			?>
	</div>
	
	<center>
	<div class="container bg-secondary text-black " style="margin-top:80px;">
		<div class="row">
			<div class="col col-sm-12 col-md-3 col-lg-8" style="margin-top: 80px;"> 
					<center>
					<h2 style="margin-left: 300px;">Contact Us</h2>
					<form action="contact-us-process.php" method="POST">
					<div class="mb-3 text-center m-5">
					    <label for="exampleInputEmail1" class="form-label" style="margin-left: 300px;">Full Name
					    <input type="text" name="full_name"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your Name"></label>
					  </div>
					  <div class="mb-3 text-center">
					    <label for="exampleInputEmail1" class="form-label" style="margin-left: 300px;">Email address
					    <input type="email" name="email"  class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your Email"></label>
					  </div>
					  <div class="form-group">
					  <label for="exampleFormControlTextarea2" style="margin-left: 300px;">Message
					  <textarea class="form-control rounded-0" name="comment"  id="exampleFormControlTextarea2" rows="4" cols="30"></textarea></label>
					  </div>
					  <div class="submit m-5" style="margin-left: 300px;">
					 <input type="submit" name="send" value="Send" style="background-color: black; color: white; width: 20%; height: 50px; font-size: 20px; margin-left: 300px; " >
					</div>
					</form>
				</center>
			</div>
		</div>
	</div>
	

	<?php
	include("include/footer.php");
	?>
	
	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

</center>
</body>
</html>