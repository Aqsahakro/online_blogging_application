<?php
	//session_start();

	if( isset($_SESSION['user']) && $_SESSION['user']['role_id'] == 1 ) 
	{
		header("location: admin/admin-dashboard.php");
	}
	elseif( isset($_SESSION['user']) && $_SESSION['user']['role_id'] == 2 ) 
	{
		header("location: user/user_dashboard.php");
	}
	
?>