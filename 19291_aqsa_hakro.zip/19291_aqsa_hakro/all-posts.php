<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Blogging Application</title>
	<style type="text/css">
		body{
			font-family: cursive;
			font-size: 20px;
		}
	</style>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<!-- Header -->
	<?php
	require_once ("require/connection.php");
	include("include/header.php");
	include("include/navbar.php");
	?>

	<!-- Header Ends -->

	<!-- Content-->
	<div class="row m-3">
		<center>
		<div class="col-8 col-sm-12 col-md-3 col-lg-8 text-center"> 
			<h2 style="font-family: cursive; color: purple;"><b>All POSTS</b></h2>
			<?php 
				$post_query = "SELECT * FROM post";

				$result = mysqli_query($connection,$post_query);

				if ( $result-> num_rows > 0 )
			 	{
					while( $row = mysqli_fetch_assoc($result) )
					{ ?>

			<div class="card mb-3 m-5">
				<div class="card-header text-white" style="font-family: cursive; background-color:#50404d; font-size: 20px;"><?php  echo $row['post_title']; ?></div>
				<img src="images/<?php  echo $row['featured_image']; ?>"  style="height: 100%;" class="img-fluid rounded-start" alt="...">
				<div class="card-body">
					<p class="card-text"><?php  echo $row['post_summary']; ?></p>
				</div>
			</div>
			<?php 
					} 
				} ?>
		</div>
		</center>
    <!-- Footer -->
    <?php
    include("include/footer.php");
    ?>
    <!-- Footer -->

	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script> +
</body>
</html>