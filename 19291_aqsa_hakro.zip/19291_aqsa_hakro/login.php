<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login Page</title>
	<style type="text/css">
	body{
			font-family: sans-serif;
			font-size: 20px;
		}
	</style>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<?php 
		require_once 'session-maintaince.php';
		include("include/header.php");
		include("include/navbar.php");

		if( isset($_GET['message']) )
		{
			?>
				<center>
				<b><p class="messgae m-5" style="color: <?php echo $_GET['color']; ?> height: 500px;">
							
				<?php echo $_GET['message']; ?>
				</p></b>
				</center>
				<?php
				}

			?>
		<div class="card text-center m-5" style="background-color: #A8A8A8; ">
			<div class="card-header bg-dark text-white">
			   Sign In
			 </div>
		<center>
  		<div class="card-body bg-secondary" style="text-align: center;  height: 400px;">
  		<form action="login-process.php" method="POST">
  			 <div>
			</div>
  			<center>
				<table style="margin-top: 50px;">
					<tr>
							<td>Email: </td>
							<td><input type="email" name="email" placeholder="enter your Email" required></td>
					</tr>
					<tr>
							<td>Password: </td>
							<td><input type="password" name="password" placeholder="enter your Password" required></td>
					</tr>
							
					<tr>
							<td colspan="2" align="center">
							<input type="submit" name="login" value="Sign In" style="margin-top:10px; width: 300px; font-weight: 2px;"><br>
							<br>
							<a href="#" style="color:darkblue; margin-top: 20px; ">Forget Password?</a></td>
							</td>
					</tr>
				</table>
				</center>	
			</form>
  	</div>
	</div>
		
	<?php
	include("include/footer.php");
	?>


	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>



</center>
</body>
</html>