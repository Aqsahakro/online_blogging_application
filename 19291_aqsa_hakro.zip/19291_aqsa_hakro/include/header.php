<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Blogging Application</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<!-- Header -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-12 text-bg-dark p-3">
				<a class="navbar-brand" href="#">
		    	<img src="images/logo.jpg " style="width: 50px;"><b style="margin:5px;">Current Events</b>
		    	</a>
				<button type="button" class="btn btn-light m-2" style="float: right;" onclick="location.href='register.php'">Register</button>
				<button type="button" class="btn btn-light m-2" style="float: right;" onclick="location.href='login.php'">Sign In</button>
			</div>
		</div>
	</div>
	<!-- Header Ends -->
</body>
</html>