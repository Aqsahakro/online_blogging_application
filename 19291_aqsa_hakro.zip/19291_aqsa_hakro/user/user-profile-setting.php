<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Blogging Application</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
	<?php
		require_once 'session-maintaince.php';
		require_once ("../require/connection.php");
		require_once ("manage-user-profile.php");
		include("include/header.php");
		include("include/navbar.php");
	?>
	<div class="container-fluid">
	<div class="row">
		<?php
		include("include/sidebar.php");

			$user = get_all_users();
			$user_id =  $_SESSION['user']['user_id'];

		?>
	<div class="col-8 text-black m-5">

		<div style="text-align: center; margin: 10px;">
			<?php 
					if( isset($_GET['message']) )
					{
					?>
						<p style="color: <?php echo $_GET['color']; ?>">
									
							<?php echo $_GET['message']; ?>
						</p>
					<?php
					}

					?>
			</div>
		<!-- Heading -->
		<div class="row">
			<?php
			if( isset($user_id) )
			{
				edit_account_details("edit-process.php","POST",$user_id);
			}
			?>	
		</div>
	</div>

	<?php

	include("include/footer.php");

	?>

	