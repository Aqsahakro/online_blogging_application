<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Blogging Application</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

</head>
<body>
	<?php 
		require_once 'session-maintaince.php';
		require_once ("../require/connection.php");
		include("include/header.php");
		include("include/navbar.php");
	?>
	<div class="container-fluid">
	<div class="row">
		<?php
		include("include/sidebar.php");

		//get active posts query
		$get_post_query = "SELECT * FROM post WHERE post_status = 'Active'";
		$result = mysqli_query($connection,$get_post_query);

		//get active posts number
		$get_active_post = "SELECT COUNT(*) AS active_post FROM post WHERE post_status = 'Active'";
		$post = mysqli_query($connection,$get_active_post);
		if( $post->num_rows > 0 )
		{
			$active_post = mysqli_fetch_assoc($post);
		}

		//get user comments query
		$get_comment_query = "SELECT COUNT(*) AS Total_comments FROM `post_comment`
						  WHERE user_id = '".$_SESSION['user']['user_id']."'";
		$query_result = mysqli_query($connection,$get_comment_query);
		if( $query_result->num_rows > 0 )
		{
			$comment = mysqli_fetch_assoc($query_result);
		}

		//get total blogs
		$get_total_blog = "SELECT COUNT(*) AS total_blogs FROM blog";
		$blog = mysqli_query($connection,$get_total_blog);
		if( $blog ->num_rows > 0 )
		{
			$total_blog = mysqli_fetch_assoc($blog);
		}

		//get active categories
		$get_active_categories = "SELECT COUNT(*) AS active_categories FROM category WHERE category_status = 'Active'";
		$category = mysqli_query($connection,$get_active_categories);
		if( $category ->num_rows > 0 )
		{
			$active_categories = mysqli_fetch_assoc($category);
		}
				
		?>
		</center>

		<!-- middle portion -->
		<div class="col-6 text-black">

		<!-- Heading -->
		<div class="row">
			<div class="col-12 mt-5">
				<h2 class="text-center"><b>Active Posts</b></h2>
			</div>
		</div>
		<!-- Heading ends -->

		<!-- Cards -->
		<div class="row">
		<?php
		if ( $result-> num_rows > 0 ) {

			while( $row = mysqli_fetch_assoc($result) )
			{ 
				?> 
		<div class="card m-5" style="max-width: 540px;" style="margin:10%; text-align: center; background-color: #e5e4e2;">
		  <div class="row g-0" style="background-color:#e5e4e2;">
		    <div class="col-md-4 mt-5" style="background-color: #e5e4e2;">
		      <img src="images/<?php  echo $row['featured_image']; ?>"  style="height: 70%;" class="img-fluid rounded-start" alt="...">
		    </div>
		    <div class="col-md-8"  style="background-color:#e5e4e2;">
		      <div class="card-body " style="background-color:#e5e4e2;">
		        <h5 class="card-title" style="font-family: cursive; background-color: #e5e4e2;"><?php echo $row['post_title']; ?></h5>
		        <p class="card-text"><?php echo $row['post_summary']; ?></p>
		        <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
		      </div>
		    </div>
		  </div>
		</div>
		<?php
			}
		}

		?>
		
		</div>

		</div>
		<!-- middle portion Ends-->


		<!-- side portion -->
		<div class="col-4 text-black text-center mt-5">
		<div class="row">
			<h2><b>Activites</b></h2>
		<div class="row m-2" style="font-family: cursive;">

			<div class="col-sm-6 mb-3 mb-sm-0">
			    <div class="card">
			      <div class="card-body">
			        <h5 class="card-title">Comments</h5>
			        <p class="card-text"><?php echo $comment['Total_comments']; ?></p>
			      </div>
			    </div>
  			</div>

			<div class="col-sm-6">
			    <div class="card">
			      <div class="card-body">
			        <h5 class="card-title">Total Active Posts</h5>
			        <p class="card-text"><?php echo $active_post['active_post']; ?> </p>
			      </div>
			    </div>
			</div>
		

			<div class="col-sm-6 mb-3 mb-sm-0 mt-3">
			    <div class="card">
			      <div class="card-body">
			        <h5 class="card-title">Total Blogs</h5>
			        <p class="card-text"><?php echo $total_blog['total_blogs']; ?></p>
			      </div>
			    </div>
  			</div>

			<div class="col-sm-6 mt-3">
			    <div class="card">
			      <div class="card-body">
			        <h5 class="card-title">Active Categories</h5>
			        <p class="card-text"><?php echo $active_categories['active_categories']; ?></p>
			      </div>
			    </div>
			</div>
		</div>	
		</div>

		</div>
		<!-- side portion Ends -->
		<?php
		include("include/footer.php");


		?>


	 <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>