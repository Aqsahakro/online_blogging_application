<?php
	require_once '../require/connection.php';
	require_once ("user-profile-setting.php");

	function get_all_users()
	{
			global $connection;
			$query = "SELECT * FROM user WHERE role_id = 2
					  ORDER BY `user`.`user_id` DESC";
			$result = mysqli_query($connection,$query);
			return $result;
		
	}
	function get_user_by_user_id($user_id)
	{
			global $connection;
			$query = "SELECT * FROM `user` WHERE `user`.`user_id` = $user_id";
			$result = mysqli_query($connection,$query);
			$data = mysqli_fetch_assoc($result);	
			return $data;
	}
	function edit_account_details($action = "",$method="GET",$user_id)
	{

		$data =  get_user_by_user_id($user_id)
		?>
		<div class="card text-center m-5" style="background-color: #A8A8A8;">
			<div class="card-header bg-dark text-white">
			    Edit Account Information
			 </div>
		 <div class="card-body text-center">
			<p class="card-text">
			<center>
		  	<form action="<?php echo $action; ?>" method="<?php echo $method; ?>">
			<input type="hidden" name="user_id" value="<?php echo $data['user_id'];?>">
			<center>
			    <form action="user-process.php" method="POST">
				<table>
					<tr>
						<th>First Name:</th>
						<td>
							<input type="text" name="first_name" required value="<?php echo $data['first_name'];?>">
						</td>
					</tr>
					<tr>
						<th>Last Name:</th>
						<td><input type="name" name="last_name" required value="<?php echo $data['last_name'];?>"></td>
					</tr>
					<tr>
						<th>Email:</th>
						<td><input type="email" name="email" required value="<?php echo $data['email'];?>" ></td>
					</tr>
					<tr>
						<th>Password:</th>
						<td><input type="password" name="password" required value="<?php echo $data['password'];?>"  ></td>
					</tr>
					<tr>
						<th>Phone Number:</th>
						<td><input type="text" name="number" required value="<?php echo $data['phone_number'];?>" ></td>
					</tr>
					<tr>
						<th>Date of Birth:</th>
						<td><input type="Date" name="dob" required value="<?php echo $data['date_of_birth'];?>" ></td>
					</tr>
					<tr>
						<th>Home Town:</th>
						<td><input type="text" name="address" required value="<?php echo $data['address'];?>" ></td>
					</tr>
					<tr>
						<th>User Status:</th>
						<td>
							<select name="status">
							<option <?php if( $data['is_active'] == 'Active' ){echo "selected"; }else { echo '';}?> >Active</option>
							<option <?php if( $data['is_active'] == 'InActive' ){echo "selected"; }else { echo '';}?>>Inactive</option>
							</select>
					</tr>
					<tr>
						<th>Gender:</th>
						<td>
							Male <input type="radio" name="gender" value="Male" <?php if( $data['gender'] == 'Male' ) echo "checked" ?> > || 

							Female <input type="radio" name="gender" value="Female" <?php  if( $data['gender'] == 'Female' ) echo "checked" ?>></td>
					</tr>
					<tr>
						<th>Image:</th>
						<td>
						<input type="file" name="image"  accept="image/png, image/jpeg" required /></td>
					</tr>
					<tr>							
						<td align="center" colspan="2">
							<input type="submit" name="update_user" value="Update User">
						</td>
					</tr>
					</table>
				</form>
				</center>
			    </p>
			  </div>
			</div>
			 <?php

	}
	?>