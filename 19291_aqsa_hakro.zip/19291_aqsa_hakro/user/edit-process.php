<?php
	require_once '../require/connection.php';

	if( isset(($_POST['update_user'])) )
	{
		extract($_POST);
		$update_user_query = "UPDATE `user` SET first_name=?,last_name=?,email=?,password=?,phone_number=?,gender=?,date_of_birth=?,user_image=?,address=?,is_active=?
			WHERE user_id = ?";

		$stmt = mysqli_prepare($connection,$update_user_query);

		mysqli_stmt_bind_param($stmt,'ssssssssssi',$first_name,$last_name,$email,$password,$number,$gender,$dob,$image,$address,$status,$user_id);

		if(mysqli_stmt_execute($stmt))
		{		
			$message = "User Updated Successfully!!";
			header("location: user-profile-setting.php?message=$message&color=green");	

		}
		else
		{
			$message = "Failed to Update User Information!";
			header("location: user-profile-setting.php?message=$message&color=red");
		}

	}


?>